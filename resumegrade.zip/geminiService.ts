
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { ResumeAnalysis, JobMatch, UserLocation, JobFilters, InterviewPrepData, LinkedInProfile, JobFitAnalysis } from "./types";

// Model constants
const ANALYSIS_MODEL = 'gemini-3-pro-preview'; // For complex thinking tasks
const QUICK_MODEL = 'gemini-3-flash-preview';   // For fast generation/rewrites
const GROUNDING_MODEL = 'gemini-2.5-flash';          // For maps and search grounding
const IMAGE_MODEL = 'gemini-2.5-flash-image';   // For image generation

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  /**
   * Performs deep resume analysis using Gemini 3 Pro reasoning.
   */
  async analyzeResume(content: string): Promise<ResumeAnalysis> {
    const prompt = `
      You are an expert ATS (Applicant Tracking System) Auditor and Executive Recruiter. 
      Analyze the provided resume text for compatibility, linguistic excellence, and extreme readability.
      
      CRITICAL AUDIT CRITERIA:
      1. STRUCTURAL RISKS: Detect tables, sidebars, or multiple columns that break parsers.
      2. SECTION HEADINGS: Ensure labels are standard (Experience, Skills, etc).
      3. LINGUISTIC RIGOR & GRAMMAR:
         - TENSE CONSISTENCY: Current roles must be present tense; past roles must be past tense. No mixing.
         - FILLER PURGE: Flag "Responsible for", "Duties included", "Assisted with", "Handled".
         - AUTHORITATIVE REWRITES: Provide direct "Original vs. Optimized" comparison.
      4. READABILITY & SKIMMABILITY (CRITICAL):
         - BULLET LENGTH: Every bullet point MUST be 1-2 lines. Flag anything longer as a "Wall of Text".
         - INFORMATION DENSITY: Detect dense paragraphs and suggest conversion to bullet points.
         - WHITE SPACE: Evaluate if sections are too cramped. Suggest where to trim text to allow the resume to "breathe".
         - HIERARCHY: Audit for clear separation between company name, role, and dates.
      5. KEYWORD DENSITY: Identify buried industry skills.
      6. QUANTIFIABLE IMPACT: Detect bullets missing metrics.

      Resume Content:
      ${content}

      Return exactly this structure:
      {
        "grade": "A" | "B" | "C" | "D" | "F",
        "totalScore": number,
        "breakdown": { "grammar": number, "ats": number, "readability": number, "content": number },
        "summary": "High-level strategic critique focusing on impact and seniority.",
        "jobKeywords": ["skill1", "skill2"],
        "suggestions": [
          {
            "category": "Grammar" | "ATS" | "Readability" | "Content",
            "issue": "Specific problem",
            "why": "Specific impact",
            "fix": "Optimized rewrite",
            "severity": "high" | "medium" | "low"
          }
        ],
        "sections": {
          "header": "string", "summary": "string", "experience": ["string"], "education": ["string"], "skills": ["string"]
        }
      }
    `;

    const response = await this.ai.models.generateContent({
      model: ANALYSIS_MODEL,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 32768 },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            grade: { type: Type.STRING },
            totalScore: { type: Type.NUMBER },
            breakdown: {
              type: Type.OBJECT,
              properties: {
                grammar: { type: Type.NUMBER },
                ats: { type: Type.NUMBER },
                readability: { type: Type.NUMBER },
                content: { type: Type.NUMBER }
              }
            },
            summary: { type: Type.STRING },
            jobKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  category: { type: Type.STRING },
                  issue: { type: Type.STRING },
                  why: { type: Type.STRING },
                  fix: { type: Type.STRING },
                  severity: { type: Type.STRING }
                }
              }
            },
            sections: {
              type: Type.OBJECT,
              properties: {
                header: { type: Type.STRING },
                summary: { type: Type.STRING },
                experience: { type: Type.ARRAY, items: { type: Type.STRING } },
                education: { type: Type.ARRAY, items: { type: Type.STRING } },
                skills: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
            }
          },
          required: ["grade", "totalScore", "breakdown", "suggestions", "sections", "summary", "jobKeywords"]
        }
      }
    });

    return JSON.parse(response.text || '{}') as ResumeAnalysis;
  }

  /**
   * Compares resume against a job description for fit analysis.
   */
  async analyzeJobFit(resume: string, jobDescription: string): Promise<JobFitAnalysis> {
    const prompt = `
      You are an ATS (Applicant Tracking System) expert. Compare the provided Resume against the provided Job Description. 
      Provide: 
      1. A Match Score (0-100%). 
      2. A Grade (e.g., Good Match, Missing Skills). 
      3. A list of exactly 5 specific keywords or skills found in the job description that are missing from the resume. 
      
      Resume:
      ${resume}
      
      Job Description:
      ${jobDescription}
    `;

    const response = await this.ai.models.generateContent({
      model: ANALYSIS_MODEL,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 32768 },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            matchScore: { type: Type.NUMBER },
            matchGrade: { type: Type.STRING },
            matchLetterGrade: { type: Type.STRING },
            hiringLikelihood: { type: Type.NUMBER },
            qualificationChecklist: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  requirement: { type: Type.STRING },
                  status: { type: Type.STRING },
                  evidence: { type: Type.STRING },
                  isMandatory: { type: Type.BOOLEAN }
                }
              }
            },
            matchingSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
            missingSkills: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "A list of exactly 5 specific keywords found in the job description missing from the resume."
            },
            gapAnalysis: { type: Type.STRING },
            tailoredSuggestions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  section: { type: Type.STRING },
                  currentText: { type: Type.STRING },
                  suggestedText: { type: Type.STRING },
                  reasoning: { type: Type.STRING }
                }
              }
            }
          },
          required: ["matchScore", "matchGrade", "matchLetterGrade", "hiringLikelihood", "qualificationChecklist", "missingSkills", "gapAnalysis", "tailoredSuggestions"]
        }
      }
    });

    return JSON.parse(response.text || '{}') as JobFitAnalysis;
  }

  /**
   * Re-writes a resume based on specific tailoring suggestions.
   */
  async applyTailoredFixes(resume: string, jobDescription: string, suggestions: any[]): Promise<string> {
    const prompt = `
      You are an expert resume optimizer. Rewrite the following resume to perfectly align with the provided job description, 
      incorporating the specific tailored suggestions provided.
      
      Resume:
      ${resume}
      
      Job Description:
      ${jobDescription}
      
      Suggestions to Apply:
      ${JSON.stringify(suggestions)}
      
      Output ONLY the full optimized resume text.
    `;

    const response = await this.ai.models.generateContent({
      model: QUICK_MODEL,
      contents: prompt
    });

    return response.text || resume;
  }

  /**
   * Optimizes LinkedIn profile data for branding and SEO.
   */
  async optimizeLinkedInProfile(sourceText: string, targetRole: string): Promise<LinkedInProfile> {
    const prompt = `
      You are a world-class LinkedIn Personal Branding Consultant and SEO specialist.
      Target Role: "${targetRole}".
      Source Content:
      ${sourceText}

      Return exactly this JSON:
      {
        "headline": "string",
        "about": "string",
        "experienceHighlights": [
          { "company": "string", "highlights": ["string"] }
        ],
        "skills": ["string"],
        "seoKeywords": ["string"],
        "bannerConcept": "string",
        "postIdeas": [
          { "title": "string", "hook": "string", "outline": "string" }
        ],
        "profileStrength": number
      }
    `;

    const response = await this.ai.models.generateContent({
      model: ANALYSIS_MODEL,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 32768 },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            headline: { type: Type.STRING },
            about: { type: Type.STRING },
            experienceHighlights: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  company: { type: Type.STRING },
                  highlights: { type: Type.ARRAY, items: { type: Type.STRING } }
                }
              }
            },
            skills: { type: Type.ARRAY, items: { type: Type.STRING } },
            seoKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            bannerConcept: { type: Type.STRING },
            postIdeas: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  hook: { type: Type.STRING },
                  outline: { type: Type.STRING }
                }
              }
            },
            profileStrength: { type: Type.NUMBER }
          },
          required: ["headline", "about", "experienceHighlights", "skills", "seoKeywords", "bannerConcept", "postIdeas", "profileStrength"]
        }
      }
    });

    return JSON.parse(response.text || '{}') as LinkedInProfile;
  }

  /**
   * Generates an actual image for a LinkedIn banner based on a concept.
   */
  async generateBannerImage(concept: string): Promise<string | null> {
    const prompt = `A professional, high-quality, minimalistic LinkedIn background banner for a professional profile. 
    Theme: ${concept}. 
    Style: Corporate but modern, clean lines, professional color palette, no text, abstract shapes or high-quality workspace imagery. 
    Aspect Ratio: Wide banner format.`;

    const response = await this.ai.models.generateContent({
      model: IMAGE_MODEL,
      contents: {
        parts: [{ text: prompt }]
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9"
        }
      }
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  }

  /**
   * Full optimization for overall resume quality.
   */
  async applyFullOptimization(content: string): Promise<string> {
    const response = await this.ai.models.generateContent({
      model: QUICK_MODEL,
      contents: `Rewrite this resume content to maximize impact, clarity, and ATS compatibility. Ensure 1-2 line bullets and use strong verbs. Content: ${content}`
    });
    return response.text || content;
  }

  /**
   * Refines experience section with active verbs.
   */
  async refineExperience(content: string): Promise<string> {
    const response = await this.ai.models.generateContent({
      model: QUICK_MODEL,
      contents: `Refine this resume experience section using strong action verbs and professional language. Content: ${content}`
    });
    return response.text || content;
  }

  /**
   * Adds quantifiable metrics to resume achievements.
   */
  async quantifyImpact(content: string): Promise<string> {
    const response = await this.ai.models.generateContent({
      model: QUICK_MODEL,
      contents: `Transform the following duties into achievement-based bullets with quantifiable metrics and impact data. Content: ${content}`
    });
    return response.text || content;
  }

  /**
   * Optimizes content for ATS keyword density and structure.
   */
  async optimizeATS(content: string): Promise<string> {
    const response = await this.ai.models.generateContent({
      model: QUICK_MODEL,
      contents: `Optimize the following content for ATS compatibility by ensuring standard terminology and clear formatting. Content: ${content}`
    });
    return response.text || content;
  }

  /**
   * Emphasizes career growth and trajectory.
   */
  async optimizeProgression(content: string): Promise<string> {
    const response = await this.ai.models.generateContent({
      model: QUICK_MODEL,
      contents: `Rewrite this resume content to clearly highlight career progression, leadership growth, and increasing scope of responsibility. Content: ${content}`
    });
    return response.text || content;
  }

  /**
   * General purpose rewrite tool with tone and role controls.
   */
  async rewriteContent(content: string, tone: string, role: string): Promise<string> {
    const response = await this.ai.models.generateContent({
      model: QUICK_MODEL,
      contents: `Rewrite the following resume section with a ${tone} tone, specifically optimized for a ${role} position. Content: ${content}`
    });
    return response.text || content;
  }

  /**
   * Generates interview preparation material.
   */
  async generateInterviewPrep(resume: string, jd: string): Promise<InterviewPrepData> {
    const prompt = `Generate tailored interview questions and winning answers based on the provided resume and job description. Resume: ${resume} JD: ${jd}`;
    const response = await this.ai.models.generateContent({
      model: ANALYSIS_MODEL,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 32768 },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overallStrategy: { type: Type.STRING },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  category: { type: Type.STRING },
                  answer: { type: Type.STRING },
                  tips: { type: Type.STRING }
                }
              }
            }
          },
          required: ["overallStrategy", "questions"]
        }
      }
    });
    return JSON.parse(response.text || '{}') as InterviewPrepData;
  }

  /**
   * Finds matching jobs using Google Search and Maps grounding.
   */
  async findMatchingJobs(keywords: string[], location: UserLocation | null, filters?: JobFilters): Promise<JobMatch[]> {
    const locationStr = location ? `at latitude ${location.latitude}, longitude ${location.longitude}` : (filters?.zipCode || "USA");
    
    // Construct a high-intent search query for Google Search Grounding
    const expTerm = filters?.experienceLevel && filters.experienceLevel !== 'Any' 
      ? `"${filters.experienceLevel}" level` 
      : "";
    
    const prompt = `
      Find active job openings for: ${keywords.join(', ')}. 
      Target location: ${locationStr}. 
      Radius constraint: ${filters?.radius || 25} miles. 
      Seniority/Experience required: ${expTerm || "Any level"}.
      Remote work preferred: ${filters?.remoteOnly ? "Yes" : "No"}.
      Job Type: ${filters?.jobType || "Any"}.
      
      Instructions: Use Google Search and Maps to verify these roles exist and are currently accepting applications. 
      Only return valid, reachable URLs.
    `;
    
    const response = await this.ai.models.generateContent({
      model: GROUNDING_MODEL,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }, { googleMaps: {} }],
        ...(location && {
          toolConfig: {
            retrievalConfig: {
              latLng: {
                latitude: location.latitude,
                longitude: location.longitude
              }
            }
          }
        })
      }
    });

    const groundedText = response.text || "";
    
    // We use a non-grounded call to reliably format the search results into valid JSON
    const formatResponse = await this.ai.models.generateContent({
      model: QUICK_MODEL,
      contents: `Convert the following job search text into a JSON array of JobMatch objects. 
      Interface: { title, company, location, link, matchPercentage, snippet }. 
      
      Note: The matchPercentage should be an estimate of how well the job title and snippet match the experience level (${filters?.experienceLevel || 'Any'}) and the keywords: ${keywords.join(', ')}. 
      
      Search Results Text: 
      ${groundedText}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              company: { type: Type.STRING },
              location: { type: Type.STRING },
              link: { type: Type.STRING },
              matchPercentage: { type: Type.NUMBER },
              snippet: { type: Type.STRING }
            },
            required: ["title", "company", "location", "link", "matchPercentage", "snippet"]
          }
        }
      }
    });

    try {
      return JSON.parse(formatResponse.text || '[]');
    } catch {
      return [];
    }
  }
}

// Fix: Export the instance of the service
export const gemini = new GeminiService();
