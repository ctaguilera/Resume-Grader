
export type Grade = 'A' | 'B' | 'C' | 'D' | 'F';

export interface Suggestion {
  category: 'Grammar' | 'ATS' | 'Readability' | 'Content';
  issue: string;
  why: string;
  fix: string;
  severity: 'high' | 'medium' | 'low';
}

export interface ScoreBreakdown {
  grammar: number;
  ats: number;
  readability: number;
  content: number;
}

export interface ResumeAnalysis {
  grade: Grade;
  totalScore: number;
  breakdown: ScoreBreakdown;
  suggestions: Suggestion[];
  summary: string;
  jobKeywords: string[];
  sections: {
    header: string;
    summary: string;
    experience: string[];
    education: string[];
    skills: string[];
  };
}

export interface JobMatch {
  title: string;
  company: string;
  location: string;
  link: string;
  matchPercentage: number;
  snippet: string;
}

export interface UserLocation {
  latitude: number;
  longitude: number;
  city?: string;
}

export interface JobFilters {
  zipCode: string;
  radius: string;
  remoteOnly: boolean;
  jobType: string;
  experienceLevel: string;
}

export interface InterviewQuestion {
  question: string;
  category: 'Behavioral' | 'Technical' | 'Cultural' | 'Strategic';
  answer: string;
  tips: string;
}

export interface InterviewPrepData {
  questions: InterviewQuestion[];
  overallStrategy: string;
}

export interface LinkedInProfile {
  headline: string;
  about: string;
  experienceHighlights: { company: string; highlights: string[] }[];
  skills: string[];
  seoKeywords: string[];
  bannerConcept: string;
  postIdeas: { title: string; hook: string; outline: string }[];
  profileStrength: number;
}

export interface JobFitAnalysis {
  matchScore: number;
  matchGrade: 'Highly Qualified' | 'Qualified' | 'Moderate' | 'Underqualified';
  matchLetterGrade: Grade;
  hiringLikelihood: number;
  qualificationChecklist: {
    requirement: string;
    status: 'Met' | 'Partial' | 'Missing';
    evidence: string;
    isMandatory: boolean;
  }[];
  matchingSkills: string[];
  missingSkills: string[];
  gapAnalysis: string;
  tailoredSuggestions: {
    section: string;
    currentText: string;
    suggestedText: string;
    reasoning: string;
  }[];
}
