
import React, { useState } from 'react';
import { Suggestion } from '../types';
import { ChevronDown, ChevronUp, AlertTriangle, CheckCircle2, Info, ArrowRight, Sparkles, LayoutPanelTop, BookOpen, Quote, Languages, Eye, Copy, Check, Download, AlertCircle } from 'lucide-react';

interface AnalysisPanelProps {
  suggestions: Suggestion[];
  summary: string;
  onApplyFix?: () => void;
  originalText: string;
  onExportPDF?: () => void;
}

const AnalysisPanel: React.FC<AnalysisPanelProps> = ({ suggestions, summary, onApplyFix, originalText, onExportPDF }) => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);
  const [copiedFull, setCopiedFull] = useState(false);
  const [showError, setShowError] = useState(false);

  const getSeverityColor = (sev: string) => {
    switch(sev) {
      case 'high': return 'bg-red-50 text-red-700 border-red-100';
      case 'medium': return 'bg-amber-50 text-amber-700 border-amber-100';
      default: return 'bg-blue-50 text-blue-700 border-blue-100';
    }
  };

  const copyFullResume = () => {
    if (!originalText || originalText.trim().length === 0) {
      setShowError(true);
      setTimeout(() => setShowError(false), 3000);
      return;
    }
    navigator.clipboard.writeText(originalText);
    setCopiedFull(true);
    setTimeout(() => setCopiedFull(false), 2000);
  };

  const getIcon = (cat: string, issue: string = '') => {
    const safeIssue = (issue || '').toLowerCase();
    
    if (safeIssue.includes('structural') || safeIssue.includes('column') || safeIssue.includes('table')) {
      return <LayoutPanelTop className="w-5 h-5" />;
    }
    if (cat === 'Readability') {
        return <Eye className="w-5 h-5" />;
    }
    if (cat === 'Grammar') {
        if (safeIssue.includes('tense')) return <Languages className="w-5 h-5" />;
        return <BookOpen className="w-5 h-5" />;
    }
    switch(cat) {
      case 'ATS': return <AlertTriangle className="w-5 h-5" />;
      case 'Grammar': return <CheckCircle2 className="w-5 h-5" />;
      default: return <Info className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6">
      {showError && (
        <div className="fixed top-20 right-8 z-[100] bg-red-600 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-right-10 duration-300">
          <AlertCircle className="w-5 h-5" />
          <p className="font-bold">Please generate an optimized resume first.</p>
        </div>
      )}

      <div className="bg-indigo-900 text-white p-8 rounded-3xl shadow-xl overflow-hidden relative group hover:shadow-indigo-900/20 transition-all duration-500">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-20 -mt-20 blur-3xl group-hover:scale-110 transition-transform duration-1000"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 relative z-10 gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-white/10 p-2 rounded-xl">
              <Sparkles className="w-5 h-5 text-indigo-300" />
            </div>
            <h3 className="text-xl font-bold">Executive Summary</h3>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button 
              onClick={copyFullResume}
              className="flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-white/20 transition-all active:scale-95"
            >
              {copiedFull ? <Check className="w-4 h-4 text-emerald-400 animate-success-pop" /> : <Copy className="w-4 h-4" />}
              {copiedFull ? 'Copied!' : 'Copy Full Resume'}
            </button>
            <button 
              onClick={onExportPDF}
              className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-indigo-500 transition-all shadow-lg active:scale-95 border border-indigo-400"
            >
              <Download className="w-4 h-4" /> Export PDF
            </button>
            <button 
              onClick={onApplyFix}
              className="hidden md:flex items-center gap-2 bg-white text-indigo-900 px-4 py-2 rounded-xl text-sm font-black hover:bg-indigo-50 transition-all shadow-lg active:scale-95"
            >
              <Sparkles className="w-4 h-4" /> Resolve All Critical Risks
            </button>
          </div>
        </div>
        <p className="text-indigo-100 leading-relaxed text-lg relative z-10 group-hover:text-white transition-colors">
          {summary}
        </p>
      </div>

      <div className="bg-white rounded-3xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-500">
        <div className="px-8 py-6 border-b border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-gray-900">Resume Audit Findings</h3>
            <p className="text-sm text-gray-500 mt-1">Specific optimizations identified by our ATS and Grammar engine.</p>
          </div>
          <button 
            onClick={onApplyFix}
            className="flex md:hidden items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-3 rounded-xl text-sm font-bold w-full active:scale-95 transition-transform"
          >
            <Sparkles className="w-4 h-4" /> Auto-Fix All Issues
          </button>
        </div>
        
        <div className="divide-y divide-gray-100">
          {suggestions.map((s, idx) => (
            <div key={idx} className={`group transition-all duration-300 ${expandedIndex === idx ? 'bg-indigo-50/10' : 'hover:bg-gray-50'}`}>
              <button
                onClick={() => setExpandedIndex(expandedIndex === idx ? null : idx)}
                className="w-full px-8 py-5 flex items-center justify-between text-left active:bg-gray-100 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg border transition-transform duration-300 ${expandedIndex === idx ? 'scale-110 shadow-sm' : 'group-hover:scale-110'} ${getSeverityColor(s.severity)}`}>
                    {getIcon(s.category, s.issue)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className={`text-xs font-bold uppercase tracking-wider ${s.category === 'Grammar' ? 'text-indigo-500' : s.category === 'Readability' ? 'text-emerald-500' : 'text-gray-400'}`}>
                        {s.category}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${getSeverityColor(s.severity)}`}>
                        {s.severity} priority
                      </span>
                    </div>
                    <p className={`font-semibold text-gray-900 transition-all ${expandedIndex === idx ? 'text-indigo-600 translate-x-1' : ''}`}>
                      {s.issue || 'Optimization Opportunity'}
                    </p>
                  </div>
                </div>
                {expandedIndex === idx ? <ChevronUp className="w-5 h-5 text-indigo-400" /> : <ChevronDown className="w-5 h-5 text-gray-400 group-hover:text-indigo-400 transition-colors" />}
              </button>
              
              {expandedIndex === idx && (
                <div className="px-8 pb-6 animate-in slide-in-from-top-2 duration-300">
                  <div className={`grid grid-cols-1 ${s.category === 'Grammar' || s.category === 'Readability' ? 'lg:grid-cols-3' : 'md:grid-cols-2'} gap-8 mt-2`}>
                    <div className="space-y-3">
                      <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-amber-500" /> Impact Analysis
                      </h4>
                      <p className="text-gray-600 text-sm leading-relaxed">{s.why}</p>
                    </div>

                    {s.category === 'Grammar' || s.category === 'Readability' ? (
                        <div className="lg:col-span-2 bg-indigo-50/30 p-6 rounded-3xl border border-indigo-100 relative overflow-hidden hover:border-indigo-300 transition-colors group/rewrite">
                             <div className="absolute top-0 right-0 p-4 opacity-5 group-hover/rewrite:scale-125 transition-transform duration-700">
                                <Quote className="w-16 h-16 text-indigo-900" />
                             </div>
                             <h4 className="text-sm font-black text-indigo-900 flex items-center gap-2 mb-4">
                                <Sparkles className="w-4 h-4 animate-pulse" /> Authoritative Rewrite
                             </h4>
                             <div className="space-y-4 relative z-10">
                                <div className="p-4 bg-white/50 rounded-xl border border-gray-100 group-hover/rewrite:bg-white transition-colors duration-300">
                                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-1">Problematic Content</span>
                                    <p className="text-sm text-gray-500 italic">Targeting specific dense or structural issues...</p>
                                </div>
                                <div className="p-4 bg-indigo-600 rounded-xl text-white shadow-xl shadow-indigo-100 group-hover/rewrite:scale-[1.02] transition-transform duration-300">
                                    <span className="text-[10px] font-black text-indigo-200 uppercase tracking-widest block mb-1">Proposed Optimization</span>
                                    <p className="text-sm font-bold leading-relaxed">"{s.fix}"</p>
                                </div>
                             </div>
                             <button 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onApplyFix?.();
                                }}
                                className="mt-4 text-xs font-black text-indigo-600 flex items-center gap-1 hover:underline active:translate-x-1 transition-all"
                             >
                                Apply this rewrite to resume <ArrowRight className="w-3 h-3" />
                             </button>
                        </div>
                    ) : (
                        <div className="bg-emerald-50/50 p-6 rounded-3xl border border-emerald-100/50 space-y-3 hover:border-emerald-300 transition-colors">
                            <h4 className="text-sm font-bold text-emerald-800 flex items-center gap-2">
                                <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Recommended Action
                            </h4>
                            <p className="text-emerald-900 text-sm italic font-medium">"{s.fix}"</p>
                            <button 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onApplyFix?.();
                                }}
                                className="text-xs font-bold text-emerald-700 flex items-center gap-1 hover:underline group-hover:gap-2 transition-all active:translate-x-1"
                            >
                                Implement optimization <ArrowRight className="w-3 h-3" />
                            </button>
                        </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AnalysisPanel;
