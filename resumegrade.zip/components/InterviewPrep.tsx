
import React, { useState } from 'react';
import { gemini } from '../geminiService';
import { InterviewPrepData } from '../types';
// Added missing Target icon import
import { Sparkles, Loader2, Send, FileText, Briefcase, BrainCircuit, CheckCircle, Lightbulb, ChevronRight, Target } from 'lucide-react';

interface InterviewPrepProps {
  initialResumeText: string;
}

const InterviewPrep: React.FC<InterviewPrepProps> = ({ initialResumeText }) => {
  const [resumeText, setResumeText] = useState(initialResumeText);
  const [jobDescription, setJobDescription] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [prepData, setPrepData] = useState<InterviewPrepData | null>(null);
  const [activeQuestion, setActiveQuestion] = useState<number>(0);

  const handleGenerate = async () => {
    if (!resumeText || !jobDescription) return;
    setIsGenerating(true);
    try {
      const data = await gemini.generateInterviewPrep(resumeText, jobDescription);
      setPrepData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="text-center py-6">
        <h2 className="text-4xl font-black text-gray-900 mb-4 tracking-tight">
          AI-Powered <span className="text-indigo-600">Interview Prep</span>
        </h2>
        <p className="text-gray-500 max-w-2xl mx-auto font-medium">
          Generate tailored interview questions and answers based on your unique resume and the specific job description.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Inputs */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="flex items-center justify-center w-6 h-6 bg-indigo-600 text-white text-xs font-bold rounded-full">1</span>
              <h3 className="font-bold text-gray-900">Your Information</h3>
            </div>
            <p className="text-xs text-gray-400">Review or paste your full resume text here.</p>
            <textarea
              className="w-full h-40 bg-gray-50 border-gray-200 rounded-2xl p-4 text-sm focus:ring-2 focus:ring-indigo-500 transition-all resize-none outline-none"
              placeholder="Paste your resume text here..."
              value={resumeText}
              onChange={(e) => setResumeText(e.target.value)}
            />
            <button className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed border-gray-200 rounded-2xl text-xs font-bold text-gray-400 hover:border-indigo-300 hover:text-indigo-600 transition-all">
              <FileText className="w-4 h-4" /> Change Resume File
            </button>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="flex items-center justify-center w-6 h-6 bg-indigo-600 text-white text-xs font-bold rounded-full">2</span>
              <h3 className="font-bold text-gray-900">Job Details</h3>
            </div>
            <p className="text-xs text-gray-400">Paste the target job description to tailor the Q&A.</p>
            <textarea
              className="w-full h-40 bg-gray-50 border-gray-200 rounded-2xl p-4 text-sm focus:ring-2 focus:ring-indigo-500 transition-all resize-none outline-none"
              placeholder="Paste the job description here..."
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
            />
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !resumeText || !jobDescription}
              className="w-full flex items-center justify-center gap-2 bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Thinking with Gemini 3 Pro...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Generate Interview Prep
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Results */}
        <div className="lg:col-span-8">
          <div className="bg-gray-900 text-white rounded-[2rem] border border-gray-800 shadow-2xl min-h-[600px] flex flex-col overflow-hidden">
            <div className="p-8 border-b border-gray-800 flex items-center justify-between bg-gray-900/50 backdrop-blur-md sticky top-0 z-10">
              <div className="flex items-center gap-3">
                <span className="flex items-center justify-center w-6 h-6 bg-indigo-500 text-white text-xs font-bold rounded-full">3</span>
                <h3 className="font-bold text-lg">Your Interview Prep</h3>
              </div>
              <div className="p-2 bg-white/5 rounded-lg border border-white/10">
                <BrainCircuit className="w-5 h-5 text-indigo-400" />
              </div>
            </div>

            {isGenerating ? (
              <div className="flex-1 flex flex-col items-center justify-center p-12 space-y-6">
                <div className="relative">
                  <div className="w-20 h-20 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin"></div>
                  <Sparkles className="absolute inset-0 m-auto w-6 h-6 text-indigo-400 animate-pulse" />
                </div>
                <div className="text-center">
                  <h4 className="text-xl font-bold mb-2">Simulating Interview Scenarios</h4>
                  <p className="text-gray-400 max-w-sm">Gemini 3 Pro is mapping your experience to the job requirements to find the perfect narrative angles.</p>
                </div>
              </div>
            ) : prepData ? (
              <div className="flex flex-col h-full">
                <div className="p-8 bg-indigo-600/10 border-b border-indigo-500/10">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-indigo-500 rounded-2xl shadow-lg shadow-indigo-500/20">
                      <Lightbulb className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-bold text-indigo-400 text-xs uppercase tracking-widest mb-1">Strategic positioning</h4>
                      <p className="text-sm text-gray-300 leading-relaxed">{prepData.overallStrategy}</p>
                    </div>
                  </div>
                </div>

                <div className="flex-1 flex">
                  {/* Sidebar with questions */}
                  <div className="w-1/3 border-r border-gray-800 overflow-y-auto max-h-[500px]">
                    {prepData.questions.map((q, idx) => (
                      <button
                        key={idx}
                        onClick={() => setActiveQuestion(idx)}
                        className={`w-full text-left p-6 border-b border-gray-800 transition-all ${activeQuestion === idx ? 'bg-indigo-600/20 border-l-4 border-l-indigo-500' : 'hover:bg-white/5'}`}
                      >
                        <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full mb-2 inline-block ${
                          q.category === 'Technical' ? 'bg-blue-500/20 text-blue-400' : 
                          q.category === 'Behavioral' ? 'bg-emerald-500/20 text-emerald-400' :
                          'bg-amber-500/20 text-amber-400'
                        }`}>
                          {q.category}
                        </span>
                        <p className="text-sm font-bold line-clamp-2 text-gray-100">{q.question}</p>
                      </button>
                    ))}
                  </div>

                  {/* Main Answer Area */}
                  <div className="flex-1 p-8 overflow-y-auto max-h-[500px] space-y-8 animate-in fade-in slide-in-from-right-4 duration-500" key={activeQuestion}>
                    <div className="space-y-4">
                      <h4 className="text-2xl font-black text-white leading-tight">
                        {prepData.questions[activeQuestion].question}
                      </h4>
                      <div className="flex items-center gap-2">
                         <span className="text-xs font-bold text-gray-500">CATEGORY:</span>
                         <span className="text-xs font-black text-indigo-400">{prepData.questions[activeQuestion].category.toUpperCase()}</span>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <div className="bg-white/5 border border-white/10 rounded-2xl p-6 relative">
                        <div className="absolute -top-3 left-6 px-3 bg-emerald-500 text-white text-[10px] font-black rounded-full py-1 uppercase shadow-lg">
                          Winning Answer
                        </div>
                        <div className="flex items-start gap-4 mt-2">
                          <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                          <p className="text-sm text-gray-300 leading-relaxed whitespace-pre-wrap">
                            {prepData.questions[activeQuestion].answer}
                          </p>
                        </div>
                      </div>

                      <div className="bg-indigo-500/5 border border-indigo-500/10 rounded-2xl p-6 relative">
                        <div className="absolute -top-3 left-6 px-3 bg-indigo-500 text-white text-[10px] font-black rounded-full py-1 uppercase shadow-lg">
                          Strategic Tips
                        </div>
                        <div className="flex items-start gap-4 mt-2">
                          <Target className="w-5 h-5 text-indigo-400 flex-shrink-0" />
                          <p className="text-sm text-gray-400 italic">
                            {prepData.questions[activeQuestion].tips}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-12 text-center">
                <div className="p-6 bg-white/5 rounded-full mb-6 border border-white/10">
                  <Briefcase className="w-12 h-12 text-gray-600" />
                </div>
                <h4 className="text-xl font-bold mb-2">Ready to practice?</h4>
                <p className="text-gray-500 max-w-xs mx-auto text-sm leading-relaxed">
                  Fill out your resume and target job details on the left, then click Generate to get customized Q&A.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InterviewPrep;
