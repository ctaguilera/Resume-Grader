
import React, { useState, useEffect } from 'react';
import { gemini } from '../geminiService';
import { JobFitAnalysis, Grade } from '../types';
import JobFitScorecard from './JobFitScorecard';
import { Target, Search, Loader2, Sparkles, CheckCircle, XCircle, AlertCircle, ArrowRight, Wand2, Copy, Check, ShieldCheck, ListCheck, Fingerprint } from 'lucide-react';

interface JobFitAnalyzerProps {
  resumeText: string;
  onUpdateResume?: (text: string) => void;
  initialJobDescription?: string;
}

const JobFitAnalyzer: React.FC<JobFitAnalyzerProps> = ({ resumeText, onUpdateResume, initialJobDescription }) => {
  const [jobDescription, setJobDescription] = useState(initialJobDescription || '');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isApplying, setIsApplying] = useState(false);
  const [analysis, setAnalysis] = useState<JobFitAnalysis | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  useEffect(() => {
    if (initialJobDescription && !analysis && !isAnalyzing) {
      handleAnalyze();
    }
  }, [initialJobDescription]);

  const handleAnalyze = async () => {
    const jdToUse = jobDescription.trim() || initialJobDescription?.trim();
    if (!jdToUse) return;
    setIsAnalyzing(true);
    try {
      const result = await gemini.analyzeJobFit(resumeText, jdToUse);
      setAnalysis(result);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleApplyAllFixes = async () => {
    if (!analysis || !onUpdateResume) return;
    setIsApplying(true);
    try {
      const updatedText = await gemini.applyTailoredFixes(resumeText, jobDescription, analysis.tailoredSuggestions);
      onUpdateResume(updatedText);
      // Re-analyze after applying to show improved match
      const result = await gemini.analyzeJobFit(updatedText, jobDescription);
      setAnalysis(result);
    } catch (err) {
      console.error(err);
    } finally {
      setIsApplying(false);
    }
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:rotate-12 transition-transform duration-700">
           <Fingerprint className="w-64 h-64 text-indigo-900" />
        </div>
        <div className="flex flex-col gap-8 relative z-10">
          <div className="flex-1 space-y-4">
            <h3 className="text-2xl font-black text-gray-900 flex items-center gap-3">
              <Search className="w-8 h-8 text-indigo-600" />
              Tailored Job Fit Audit
            </h3>
            <p className="text-gray-500 font-medium max-w-xl">
              Paste the target job description to see how your resume stacks up against specific requirements and ATS criteria.
            </p>
            <div className="relative">
              <textarea
                className="w-full h-72 bg-gray-50 border-gray-200 rounded-3xl p-6 text-sm focus:ring-2 focus:ring-indigo-500 transition-all resize-none outline-none font-medium text-gray-700"
                placeholder="Paste the full job description or requirements section here..."
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
              />
              <div className="absolute bottom-4 right-4 text-[10px] font-black text-gray-300 uppercase tracking-widest">
                Real-time JD Parser Ready
              </div>
            </div>
            <div className="flex gap-4">
              <button
                onClick={handleAnalyze}
                disabled={isAnalyzing || !jobDescription.trim()}
                className="flex-1 md:flex-none px-10 py-5 bg-gray-900 text-white rounded-2xl font-black shadow-2xl hover:bg-black transition-all disabled:opacity-50 flex items-center justify-center gap-3 active:scale-95"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Calculating Fit...
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-5 h-5" />
                    Audit My Resume
                  </>
                )}
              </button>
              {analysis && (
                <button
                  onClick={() => { setAnalysis(null); setJobDescription(''); }}
                  className="px-6 py-5 bg-gray-100 text-gray-600 rounded-2xl font-bold hover:bg-gray-200 transition-all active:scale-95"
                >
                  Clear Results
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {analysis && (
        <>
          {/* New Scorecard Component */}
          <JobFitScorecard analysis={analysis} />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Audit Checklist */}
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 p-6 opacity-5">
                   <ListCheck className="w-32 h-32" />
                </div>
                <div className="flex items-center justify-between mb-8 relative z-10">
                   <h4 className="text-xl font-black text-gray-900 flex items-center gap-2">
                    <CheckCircle className="w-6 h-6 text-indigo-600" />
                    Requirement Fulfillment Checklist
                  </h4>
                  <div className="flex items-center gap-4">
                     <div className="h-2 w-32 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-emerald-500 rounded-full transition-all duration-1000"
                          style={{ width: `${(analysis.qualificationChecklist.filter(q => q.status === 'Met').length / analysis.qualificationChecklist.length) * 100}%` }}
                        />
                     </div>
                     <span className="text-[10px] font-black text-gray-400 uppercase">Verification Progress</span>
                  </div>
                </div>
                
                <div className="space-y-4 relative z-10">
                  {analysis.qualificationChecklist.map((q, i) => (
                    <div key={i} className={`p-5 rounded-[1.5rem] border transition-all hover:translate-x-1 duration-300 ${
                      q.status === 'Met' ? 'bg-emerald-50/20 border-emerald-100' : 
                      q.status === 'Partial' ? 'bg-amber-50/20 border-amber-100' : 'bg-red-50/20 border-red-100'
                    }`}>
                      <div className="flex items-start justify-between gap-4">
                         <div className="flex gap-4">
                            <div className={`mt-1 p-1.5 rounded-lg flex-shrink-0 ${
                              q.status === 'Met' ? 'bg-emerald-500 text-white' : 
                              q.status === 'Partial' ? 'bg-amber-500 text-white' : 'bg-red-500 text-white'
                            }`}>
                              {q.status === 'Met' ? <CheckCircle className="w-4 h-4" /> : 
                               q.status === 'Partial' ? <AlertCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                            </div>
                            <div>
                              <p className="text-sm font-black text-gray-900 flex items-center gap-2">
                                {q.requirement}
                                {q.isMandatory && (
                                  <span className="text-[8px] font-black text-red-500 bg-red-100 px-1.5 py-0.5 rounded-sm uppercase tracking-tighter">Mandatory</span>
                                )}
                              </p>
                              <p className="text-xs text-gray-500 mt-1 leading-relaxed font-medium">
                                {q.evidence || "Evidence not found. Recruiting algorithm may flag this as a missing requirement."}
                              </p>
                            </div>
                         </div>
                         <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full flex-shrink-0 h-fit ${
                            q.status === 'Met' ? 'text-emerald-600 bg-emerald-100' : 
                            q.status === 'Partial' ? 'text-amber-600 bg-amber-100' : 'text-red-600 bg-red-100'
                         }`}>
                           {q.status}
                         </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Rewrite Suggestions */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm h-full flex flex-col">
                <div className="mb-8">
                  <h4 className="text-xl font-black text-gray-900 flex items-center gap-2">
                    <Wand2 className="w-6 h-6 text-indigo-600" />
                    Tailored Resume Fixes
                  </h4>
                  <p className="text-xs text-gray-500 mt-2 font-medium leading-relaxed">
                    Bridge the gap! These specific rewrites will insert the missing keywords and evidence required for this specific role.
                  </p>
                </div>
                
                <div className="space-y-6 flex-grow overflow-y-auto pr-2 max-h-[500px]">
                  {analysis.tailoredSuggestions.map((s, i) => (
                    <div key={i} className="space-y-3 group">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-black uppercase tracking-widest text-indigo-500 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100">
                          {s.section}
                        </span>
                        <button 
                          onClick={() => copyToClipboard(s.suggestedText, i)}
                          className="text-[10px] font-black text-gray-400 hover:text-indigo-600 flex items-center gap-1 transition-colors group-hover:underline"
                        >
                          {copiedIndex === i ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                          {copiedIndex === i ? 'Copied' : 'Copy'}
                        </button>
                      </div>
                      
                      <div className="p-5 bg-gray-50 rounded-2xl border border-gray-100 group-hover:border-indigo-200 group-hover:bg-indigo-50/20 transition-all duration-300">
                        <p className="text-xs text-gray-700 font-bold leading-relaxed italic mb-3 opacity-60">"Current: {s.currentText.substring(0, 60)}..."</p>
                        <p className="text-xs text-gray-900 font-black leading-relaxed">Suggested: "{s.suggestedText}"</p>
                        <div className="mt-3 flex items-start gap-2 text-[10px] italic text-gray-400 font-medium">
                          <ArrowRight className="w-2.5 h-2.5 mt-0.5 flex-shrink-0 text-indigo-400" /> 
                          <span>Reason: {s.reasoning}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-12 pt-8 border-t border-gray-50">
                   <button 
                      onClick={handleApplyAllFixes}
                      disabled={isApplying || !onUpdateResume}
                      className="w-full flex items-center justify-center gap-3 bg-indigo-600 text-white py-5 rounded-2xl font-black shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95 group disabled:opacity-50"
                   >
                      {isApplying ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Optimizing Resume...
                        </>
                      ) : (
                        <>
                          Implement All Recommendations
                          <Sparkles className="w-4 h-4 group-hover:rotate-12 transition-transform" />
                        </>
                      )}
                   </button>
                   <p className="text-[10px] text-gray-400 text-center mt-4 font-bold uppercase tracking-widest">
                     Persists changes to your main resume for downloading
                   </p>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default JobFitAnalyzer;
