
import React, { useState } from 'react';
import { JobMatch, JobFilters } from '../types';
import { ExternalLink, MapPin, Building2, TrendingUp, Search, ChevronDown, Share2, Mail, Twitter, Linkedin, Copy, Check, X, Navigation, Locate, BarChart, Award, Shield, User, Zap } from 'lucide-react';

interface JobMatchListProps {
  jobs: JobMatch[];
  onRefreshJobs: (filters: JobFilters) => void;
  isLoading?: boolean;
}

interface ShareModalProps {
  job: JobMatch;
  onClose: () => void;
}

const ShareModal: React.FC<ShareModalProps> = ({ job, onClose }) => {
  const [copied, setCopied] = useState(false);

  const shareLinks = {
    email: `mailto:?subject=Check out this job: ${job.title}&body=I thought you might be interested in this job at ${job.company}: ${job.link}`,
    twitter: `https://twitter.com/intent/tweet?text=Check out this job: ${job.title} at ${job.company}&url=${encodeURIComponent(job.link)}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(job.link)}`
  };

  const copyLink = () => {
    navigator.clipboard.writeText(job.link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
        <div className="p-8 border-b border-gray-100 flex items-center justify-between">
          <h3 className="text-xl font-black text-gray-900">Share Job Opportunity</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-all text-gray-400 hover:text-gray-900 active:rotate-90">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-8 space-y-6">
          <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 hover:bg-gray-100 transition-colors">
            <p className="text-xs font-bold text-gray-400 uppercase mb-1">Position</p>
            <p className="font-bold text-gray-900">{job.title}</p>
            <p className="text-sm text-gray-500">{job.company}</p>
          </div>

          <div className="grid grid-cols-4 gap-4">
            {[
              { id: 'email', icon: Mail, label: 'Email', color: 'bg-red-50 text-red-600', link: shareLinks.email },
              { id: 'twitter', icon: Twitter, label: 'Twitter', color: 'bg-sky-50 text-sky-600', link: shareLinks.twitter },
              { id: 'linkedin', icon: Linkedin, label: 'LinkedIn', color: 'bg-blue-50 text-blue-600', link: shareLinks.linkedin },
              { id: 'copy', icon: copied ? Check : Copy, label: copied ? 'Copied' : 'Copy', color: 'bg-gray-50 text-gray-600', action: copyLink },
            ].map((item) => (
              <div key={item.id} className="flex flex-col items-center gap-2">
                {item.link ? (
                  <a
                    href={item.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-14 h-14 ${item.color} rounded-2xl flex items-center justify-center shadow-sm hover:scale-110 hover:-translate-y-1 transition-all active:scale-95`}
                  >
                    <item.icon className="w-6 h-6" />
                  </a>
                ) : (
                  <button
                    onClick={item.action}
                    className={`w-14 h-14 ${item.color} rounded-2xl flex items-center justify-center shadow-sm hover:scale-110 hover:-translate-y-1 transition-all active:scale-95`}
                  >
                    <item.icon className={`w-6 h-6 ${copied ? 'text-emerald-600 scale-125' : ''} transition-all duration-300`} />
                  </button>
                )}
                <span className="text-[10px] font-black uppercase tracking-wider text-gray-400">{item.label}</span>
              </div>
            ))}
          </div>

          <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-100 hover:shadow-inner transition-shadow">
            <p className="text-xs text-indigo-800 leading-relaxed font-medium">
              Help your network find their next career move. Sharing opportunities is a great way to stay connected.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const JobMatchList: React.FC<JobMatchListProps> = ({ jobs, onRefreshJobs, isLoading }) => {
  const [filters, setFilters] = useState<JobFilters>({
    zipCode: '',
    radius: '25',
    remoteOnly: false,
    jobType: 'Any',
    experienceLevel: 'Any'
  });

  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [sharingJob, setSharingJob] = useState<JobMatch | null>(null);

  const toggleDropdown = (name: string) => {
    setActiveDropdown(activeDropdown === name ? null : name);
  };

  const handleApplyFilters = () => {
    setActiveDropdown(null);
    onRefreshJobs(filters);
  };

  const getExperienceIcon = (level: string) => {
    switch(level) {
        case 'Entry': return <User className="w-4 h-4" />;
        case 'Mid': return <Zap className="w-4 h-4" />;
        case 'Senior': return <Award className="w-4 h-4" />;
        case 'Executive': return <Shield className="w-4 h-4" />;
        default: return <BarChart className="w-4 h-4" />;
    }
  };

  const FilterButton = ({ label, value, name, options }: { label: string, value: string, name: string, options?: string[] }) => {
    const isActive = value !== 'Any' && value !== '' && value !== 'Any level';
    return (
        <div className="relative">
          <button 
            onClick={() => toggleDropdown(name)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-bold transition-all active:scale-95 ${
              isActive
                ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-100' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <span className="flex items-center gap-1.5">
                {name === 'experienceLevel' && isActive && getExperienceIcon(value)}
                {label}: {value}
            </span>
            <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${activeDropdown === name ? 'rotate-180' : ''}`} />
          </button>
          
          {activeDropdown === name && options && (
            <div className="absolute top-full mt-2 left-0 w-48 bg-white border border-gray-200 rounded-2xl shadow-xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
              {options.map(opt => (
                <button
                  key={opt}
                  className={`w-full text-left px-4 py-3 hover:bg-indigo-50 hover:text-indigo-600 text-sm font-bold transition-all border-b last:border-0 border-gray-100 active:bg-indigo-100 ${value === opt ? 'bg-indigo-50 text-indigo-600' : ''}`}
                  onClick={() => {
                    setFilters({ ...filters, [name]: opt });
                    setActiveDropdown(null);
                  }}
                >
                  <span className="flex items-center gap-2">
                    {name === 'experienceLevel' && opt !== 'Any' && <span>{getExperienceIcon(opt)}</span>}
                    {opt}{name === 'radius' ? ' miles' : ''}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
    );
  };

  return (
    <div className="space-y-6">
      {sharingJob && <ShareModal job={sharingJob} onClose={() => setSharingJob(null)} />}

      <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-500">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h3 className="text-2xl font-black text-gray-900 flex items-center gap-3">
              <Search className="w-6 h-6 text-indigo-600 group-hover:scale-110 transition-transform" />
              Real-Time Job Matches
            </h3>
            <p className="text-gray-500 font-medium">Verified roles sourced via high-intent Search & Maps grounding.</p>
          </div>
          <div className="flex gap-4">
             <div className="bg-emerald-50 px-4 py-2 rounded-2xl border border-emerald-100 flex items-center gap-2 hover:bg-emerald-100 transition-colors">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                <span className="text-sm font-black text-emerald-700">{jobs.length} Matches Found</span>
             </div>
          </div>
        </div>

        {/* Unified Filter Bar with Location Pillar */}
        <div className="flex flex-wrap items-center gap-4 mb-8 pb-8 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="relative group">
              <input 
                type="text"
                placeholder="ZIP Code"
                maxLength={5}
                className="pl-10 pr-4 py-2.5 bg-gray-100 border-none rounded-full text-sm font-bold w-36 focus:ring-2 focus:ring-indigo-500 transition-all hover:bg-gray-200"
                value={filters.zipCode}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '');
                  setFilters({...filters, zipCode: val});
                }}
              />
              <MapPin className={`absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 transition-all duration-300 ${filters.zipCode ? 'text-indigo-600 scale-110' : 'text-gray-400'}`} />
            </div>

            <FilterButton 
              label="Radius" 
              value={`${filters.radius}mi`} 
              name="radius" 
              options={['5', '10', '25', '50', '100']} 
            />
          </div>

          <div className="h-8 w-px bg-gray-100 hidden md:block" />
          
          <FilterButton 
            label="Job Type" 
            value={filters.jobType} 
            name="jobType" 
            options={['Any', 'Full-time', 'Contract', 'Part-time', 'Freelance']} 
          />

          <FilterButton 
            label="Seniority" 
            value={filters.experienceLevel} 
            name="experienceLevel" 
            options={['Any', 'Entry', 'Mid', 'Senior', 'Executive']} 
          />

          <button 
            onClick={() => setFilters({...filters, remoteOnly: !filters.remoteOnly})}
            className={`px-5 py-2.5 rounded-full text-sm font-bold transition-all flex items-center gap-2 active:scale-95 ${
              filters.remoteOnly 
                ? 'bg-indigo-600 text-white shadow-md' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Navigation className={`w-3.5 h-3.5 transition-all duration-300 ${filters.remoteOnly ? 'animate-pulse scale-110 rotate-12' : ''}`} />
            Remote Only
          </button>

          <div className="flex-grow"></div>

          <button 
            onClick={handleApplyFilters}
            disabled={isLoading}
            className="bg-gray-900 text-white px-8 py-2.5 rounded-full font-black shadow-xl hover:bg-black transition-all flex items-center gap-2 disabled:opacity-50 active:scale-95 hover:-translate-y-0.5"
          >
            {isLoading ? <Locate className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4 group-hover:scale-125 transition-transform" />}
            Refresh Search
          </button>
        </div>

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-24 space-y-6">
             <div className="relative group">
                <div className="w-20 h-20 border-4 border-indigo-50 border-t-indigo-600 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center group-hover:scale-125 transition-transform duration-500">
                   <Locate className="w-8 h-8 text-indigo-400" />
                </div>
             </div>
             <div className="text-center">
                <p className="text-gray-900 font-black text-xl tracking-tight">Geo-referencing local listings...</p>
                <p className="text-gray-500 font-medium mt-1">Sourcing real-time vacancies for {filters.experienceLevel} level talent.</p>
             </div>
          </div>
        ) : jobs.length === 0 ? (
          <div className="text-center py-20 border-2 border-dashed border-gray-100 rounded-[2.5rem] bg-gray-50/50 hover:bg-gray-50 transition-colors duration-500">
            <div className="p-6 bg-white rounded-full inline-block mb-4 shadow-sm group hover:scale-110 transition-transform">
              <Search className="w-12 h-12 text-gray-200 group-hover:text-indigo-200 transition-colors" />
            </div>
            <h4 className="text-xl font-black text-gray-900">No matching vacancies found.</h4>
            <p className="text-gray-500 mt-2 max-w-xs mx-auto font-medium">Try increasing your search radius or broadening your seniority level to capture more opportunities.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5">
            {jobs.map((job, idx) => (
              <div
                key={idx}
                className="group p-8 rounded-[2rem] bg-white border border-gray-100 hover:border-indigo-200 hover:shadow-2xl hover:shadow-indigo-100/20 hover:-translate-y-1 transition-all duration-500 animate-in fade-in slide-in-from-bottom-2"
                style={{ animationDelay: `${idx * 100}ms` }}
              >
                <div className="flex flex-col md:flex-row gap-8 justify-between">
                  <div className="flex gap-6 flex-grow">
                    <div className="w-20 h-20 bg-gray-50 rounded-3xl flex items-center justify-center flex-shrink-0 group-hover:bg-indigo-50 transition-all duration-500 border border-gray-100 group-hover:rotate-3">
                      <Building2 className="w-10 h-10 text-gray-300 group-hover:text-indigo-600 group-hover:scale-110 transition-all duration-500" />
                    </div>
                    <div className="space-y-1 flex-grow">
                      <div className="flex items-center gap-3 flex-wrap">
                        <h4 className="text-xl font-black text-gray-900 group-hover:text-indigo-600 transition-colors tracking-tight">{job.title}</h4>
                        <div className="flex gap-2">
                            <span className="bg-indigo-50 text-indigo-600 text-[10px] font-black uppercase px-3 py-1 rounded-full border border-indigo-100 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-500">
                              {job.matchPercentage}% Relevance
                            </span>
                            {filters.experienceLevel !== 'Any' && (
                                <span className="bg-gray-100 text-gray-600 text-[10px] font-black uppercase px-3 py-1 rounded-full border border-gray-200 flex items-center gap-1">
                                    {getExperienceIcon(filters.experienceLevel)}
                                    {filters.experienceLevel} level
                                </span>
                            )}
                        </div>
                      </div>
                      <div className="flex items-center gap-5 text-sm text-gray-500 font-bold">
                        <span className="flex items-center gap-1.5 group-hover:text-gray-700 transition-colors">
                          <Building2 className="w-4 h-4 text-gray-400" /> {job.company}
                        </span>
                        <span className="flex items-center gap-1.5 group-hover:text-gray-700 transition-colors">
                          <MapPin className="w-4 h-4 text-gray-400" /> {job.location}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500 line-clamp-2 mt-4 leading-relaxed font-medium group-hover:text-gray-600 transition-colors">
                        {job.snippet}
                      </p>
                    </div>
                  </div>
                  <div className="flex md:flex-col items-center justify-end gap-3 flex-shrink-0">
                    <button
                      onClick={() => setSharingJob(job)}
                      className="p-4 bg-gray-50 text-gray-400 rounded-2xl hover:bg-indigo-600 hover:text-white hover:shadow-lg transition-all active:scale-95 border border-gray-100"
                      title="Share Opportunity"
                    >
                      <Share2 className="w-5 h-5" />
                    </button>
                    <a
                      href={job.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-gray-900 text-white p-4 rounded-2xl hover:bg-indigo-600 hover:shadow-xl hover:-translate-x-1 transition-all active:scale-95 shadow-lg"
                      title="Apply Now"
                    >
                      <ExternalLink className="w-6 h-6" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-gradient-to-br from-indigo-900 to-indigo-800 p-12 rounded-[3rem] text-white shadow-2xl relative overflow-hidden group hover:shadow-indigo-900/40 transition-all duration-700">
        <div className="absolute top-0 right-0 p-10 opacity-10 group-hover:scale-110 group-hover:rotate-12 transition-transform duration-1000">
           <Locate className="w-64 h-64" />
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
          <div className="space-y-6">
            <h3 className="text-4xl font-black tracking-tight leading-tight group-hover:translate-x-1 transition-transform duration-500">Hyper-Local Job Intelligence.</h3>
            <p className="text-indigo-100 text-lg font-medium leading-relaxed">
              We don't just search the web; we geo-fence your seniority and skills against local demand to find the highest-matching roles in your area.
            </p>
          </div>
          <div className="flex lg:justify-end gap-6">
             <button className="bg-white text-indigo-900 px-10 py-5 rounded-[2rem] font-black shadow-xl hover:scale-105 active:scale-95 hover:shadow-2xl transition-all duration-300">
                Enhance Search Strategy
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobMatchList;
