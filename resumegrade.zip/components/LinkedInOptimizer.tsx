
import React, { useState } from 'react';
import { gemini } from '../geminiService';
import { LinkedInProfile } from '../types';
import { Linkedin, Sparkles, Loader2, Copy, Check, Info, Layout, Type, Briefcase, Hash, Share2, TrendingUp, Image as ImageIcon, MessageSquare, ChevronRight, PenTool, ExternalLink, UserCircle, Download, Wand2, Lightbulb, FileText, Award, Star } from 'lucide-react';

interface LinkedInOptimizerProps {
  initialResumeText: string;
}

const LinkedInOptimizer: React.FC<LinkedInOptimizerProps> = ({ initialResumeText }) => {
  const [sourceText, setSourceText] = useState(initialResumeText);
  const [targetRole, setTargetRole] = useState('');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [isGeneratingBanner, setIsGeneratingBanner] = useState(false);
  const [optimizedProfile, setOptimizedProfile] = useState<LinkedInProfile | null>(null);
  const [bannerUrl, setBannerUrl] = useState<string | null>(null);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [inputType, setInputType] = useState<'resume' | 'existing'>('resume');

  const handleOptimize = async () => {
    if (!sourceText || !targetRole) return;
    setIsOptimizing(true);
    setBannerUrl(null);
    try {
      const data = await gemini.optimizeLinkedInProfile(sourceText, targetRole);
      setOptimizedProfile(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleGenerateBanner = async () => {
    if (!optimizedProfile) return;
    setIsGeneratingBanner(true);
    try {
      const url = await gemini.generateBannerImage(optimizedProfile.bannerConcept);
      setBannerUrl(url);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingBanner(false);
    }
  };

  const handleDownloadBanner = () => {
    if (!bannerUrl) return;
    const link = document.createElement('a');
    link.href = bannerUrl;
    link.download = `linkedin-banner-${targetRole.toLowerCase().replace(/\s+/g, '-')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const copyToClipboard = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const copyAll = () => {
    if (!optimizedProfile) return;
    const allText = `
HEADLINE:
${optimizedProfile.headline}

ABOUT:
${optimizedProfile.about}

EXPERIENCE HIGHLIGHTS:
${optimizedProfile.experienceHighlights.map(e => `${e.company}:\n${e.highlights.map(h => `- ${h}`).join('\n')}`).join('\n\n')}

TOP SKILLS:
${optimizedProfile.skills.join(', ')}

SEO KEYWORDS:
${optimizedProfile.seoKeywords.join(', ')}
    `.trim();
    copyToClipboard(allText, 'copyall');
  };

  const getProfileLevel = (strength: number) => {
    if (strength >= 90) return { label: 'All-Star', color: 'text-indigo-600', bg: 'bg-indigo-600' };
    if (strength >= 75) return { label: 'Advanced', color: 'text-blue-600', bg: 'bg-blue-600' };
    if (strength >= 50) return { label: 'Intermediate', color: 'text-emerald-600', bg: 'bg-emerald-600' };
    return { label: 'Beginner', color: 'text-amber-600', bg: 'bg-amber-600' };
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="text-center py-6">
        <div className="inline-flex items-center gap-2 bg-[#0077b5] text-white px-4 py-1.5 rounded-full text-xs font-black uppercase mb-4 shadow-lg shadow-blue-100 animate-pulse">
          <Linkedin className="w-3.5 h-3.5" /> Identity & Brand Builder
        </div>
        <h2 className="text-4xl font-black text-gray-900 mb-4 tracking-tight">
          LinkedIn <span className="text-[#0077b5]">Presence Architect</span>
        </h2>
        <p className="text-gray-500 max-w-2xl mx-auto font-medium">
          Transform your career history into an authoritative personal brand that resonates with recruiters and executive leadership.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Input Dashboard */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm space-y-6">
            <div className="flex gap-2 bg-gray-50 p-1 rounded-xl">
              <button 
                onClick={() => setInputType('resume')}
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all active:scale-95 ${inputType === 'resume' ? 'bg-white shadow-sm text-[#0077b5]' : 'text-gray-400 hover:text-gray-600'}`}
              >
                Scan Resume
              </button>
              <button 
                onClick={() => setInputType('existing')}
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all active:scale-95 ${inputType === 'existing' ? 'bg-white shadow-sm text-[#0077b5]' : 'text-gray-400 hover:text-gray-600'}`}
              >
                Scan Profile
              </button>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Layout className="w-5 h-5 text-[#0077b5]" />
                <h3 className="font-bold text-gray-900 text-sm">Source Intelligence</h3>
              </div>
              <textarea
                className="w-full h-48 bg-gray-50 border-gray-200 rounded-2xl p-4 text-xs focus:ring-2 focus:ring-[#0077b5] transition-all resize-none outline-none font-medium text-gray-600 focus:bg-white"
                placeholder={inputType === 'resume' ? "Paste your full resume text..." : "Paste your current LinkedIn 'About' and 'Experience' sections..."}
                value={sourceText}
                onChange={(e) => setSourceText(e.target.value)}
              />
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-[#0077b5]" />
                <h3 className="font-bold text-gray-900 text-sm">Goal Position</h3>
              </div>
              <input
                type="text"
                className="w-full bg-gray-50 border-gray-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#0077b5] outline-none font-bold focus:bg-white transition-all"
                placeholder="e.g. Director of Engineering..."
                value={targetRole}
                onChange={(e) => setTargetRole(e.target.value)}
              />
            </div>

            <button
              onClick={handleOptimize}
              disabled={isOptimizing || !sourceText || !targetRole}
              className="w-full flex items-center justify-center gap-2 bg-[#0077b5] text-white py-4 rounded-2xl font-black shadow-xl hover:bg-blue-700 transition-all disabled:opacity-50 active:scale-95 group hover:-translate-y-0.5"
            >
              {isOptimizing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Generating Identity...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                  Optimize My Profile
                </>
              )}
            </button>
          </div>

          {optimizedProfile && (
            <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm transition-all hover:shadow-xl hover:-translate-y-1 relative overflow-hidden group">
               <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                  <Star className="w-24 h-24 text-[#0077b5]" />
               </div>
               
               <div className="flex items-center justify-between mb-6">
                 <h4 className="text-sm font-black text-gray-900 flex items-center gap-2 uppercase tracking-widest">
                   <TrendingUp className="w-4 h-4 text-[#0077b5]" /> Profile Strength
                 </h4>
                 <div className="flex flex-col items-end">
                    <span className={`text-2xl font-black ${getProfileLevel(optimizedProfile.profileStrength).color}`}>
                      {optimizedProfile.profileStrength}%
                    </span>
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">All-Star Threshold</span>
                 </div>
               </div>
               
               {/* LinkedIn-style Multi-Segmented Progress Bar */}
               <div className="grid grid-cols-5 gap-1.5 h-3 mb-4">
                  {[20, 40, 60, 80, 100].map((step, idx) => {
                    const isActive = optimizedProfile.profileStrength >= step;
                    const isLastActive = optimizedProfile.profileStrength >= step && (optimizedProfile.profileStrength < step + 20 || step === 100);
                    return (
                      <div 
                        key={idx} 
                        className={`rounded-full transition-all duration-1000 ${
                          isActive 
                            ? `${getProfileLevel(optimizedProfile.profileStrength).bg} ${isLastActive ? 'animate-pulse' : ''}` 
                            : 'bg-gray-100'
                        }`}
                      />
                    );
                  })}
               </div>

               <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-2xl border border-gray-100 mb-6">
                  <div className={`p-2 rounded-xl ${getProfileLevel(optimizedProfile.profileStrength).bg} text-white`}>
                    <Award className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Current Status</p>
                    <p className={`text-sm font-black ${getProfileLevel(optimizedProfile.profileStrength).color}`}>
                      {getProfileLevel(optimizedProfile.profileStrength).label}
                    </p>
                  </div>
               </div>

               <p className="text-xs text-gray-500 font-medium leading-relaxed italic mb-6">
                Your profile is optimized for maximum recruiter visibility. An All-Star rating increases your chances of being found by {optimizedProfile.profileStrength > 80 ? '27x' : '15x'}.
               </p>

               <button 
                  onClick={copyAll}
                  className="w-full py-4 bg-gray-900 text-white rounded-2xl font-black text-xs hover:bg-black transition-all flex items-center justify-center gap-2 shadow-lg active:scale-95"
               >
                 {copiedSection === 'copyall' ? <Check className="w-4 h-4 text-emerald-400 animate-success-pop" /> : <Copy className="w-4 h-4" />}
                 {copiedSection === 'copyall' ? 'Success! Profile Copied' : 'Copy Optimized Brand'}
               </button>
            </div>
          )}
        </div>

        {/* Right: Output Board */}
        <div className="lg:col-span-8">
          <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-2xl overflow-hidden min-h-[700px] flex flex-col">
            <div className="p-8 border-b border-gray-50 flex items-center justify-between bg-white sticky top-0 z-20">
              <h3 className="font-black text-xl text-gray-900 flex items-center gap-3">
                <Share2 className="w-6 h-6 text-[#0077b5]" /> Brand Architecture
              </h3>
              <div className="flex gap-2">
                 <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                 <div className="w-3 h-3 bg-amber-400 rounded-full"></div>
                 <div className="w-3 h-3 bg-emerald-400 rounded-full"></div>
              </div>
            </div>

            {!optimizedProfile && !isOptimizing ? (
              <div className="flex-1 flex flex-col items-center justify-center p-12 text-center">
                <div className="p-8 bg-gray-50 rounded-full mb-6 border border-gray-100 group hover:scale-110 transition-transform">
                  <Linkedin className="w-16 h-16 text-gray-200 group-hover:text-[#0077b5] transition-colors" />
                </div>
                <h4 className="text-xl font-black text-gray-400 uppercase tracking-tighter">Identity Engine Idle</h4>
                <p className="text-gray-400 max-w-xs mx-auto text-sm mt-3 font-medium">
                  Define your target role to generate high-converting headlines, story-driven summaries, and an algorithmic SEO strategy.
                </p>
              </div>
            ) : isOptimizing ? (
              <div className="flex-1 flex flex-col items-center justify-center p-12 space-y-8">
                <div className="relative">
                  <div className="w-24 h-24 border-4 border-[#0077b5]/10 border-t-[#0077b5] rounded-full animate-spin"></div>
                  <Sparkles className="absolute inset-0 m-auto w-8 h-8 text-[#0077b5] animate-pulse" />
                </div>
                <div className="text-center">
                  <h4 className="text-2xl font-black text-gray-900 mb-2">Architecting Brand Identity</h4>
                  <p className="text-gray-500 max-w-sm font-medium">Synthesizing executive storytelling and SEO metadata for your new LinkedIn presence.</p>
                </div>
              </div>
            ) : (
              <div className="p-8 space-y-12 overflow-y-auto max-h-[800px] scroll-smooth">
                {/* Visual Preview Header */}
                <div className="relative border border-gray-200 rounded-[2rem] overflow-hidden group/header">
                   <div className="h-48 bg-gray-100 relative overflow-hidden">
                      {isGeneratingBanner ? (
                        <div className="w-full h-full flex flex-col items-center justify-center bg-gray-900 space-y-4">
                           <Loader2 className="w-8 h-8 text-indigo-400 animate-spin" />
                           <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] animate-pulse">Painting Brand Visuals...</p>
                        </div>
                      ) : bannerUrl ? (
                        <img src={bannerUrl} alt="LinkedIn Banner" className="w-full h-full object-cover animate-in fade-in duration-1000 hover:scale-105 transition-transform duration-[2000ms]" />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-r from-[#0077b5] to-blue-400 flex items-center justify-center text-white/20">
                           <ImageIcon className="w-16 h-16" />
                        </div>
                      )}
                      
                      <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover/header:opacity-100 transition-opacity duration-300 translate-y-2 group-hover/header:translate-y-0">
                        {bannerUrl && (
                          <button 
                            onClick={handleDownloadBanner}
                            className="px-4 py-2 bg-black/40 backdrop-blur-md rounded-xl text-[10px] font-black text-white uppercase tracking-widest border border-white/20 hover:bg-black/60 transition-all flex items-center gap-2 active:scale-95"
                          >
                            <Download className="w-3.5 h-3.5" /> Save Image
                          </button>
                        )}
                        <button 
                          onClick={handleGenerateBanner}
                          disabled={isGeneratingBanner}
                          className="px-4 py-2 bg-indigo-600/90 backdrop-blur-md rounded-xl text-[10px] font-black text-white uppercase tracking-widest border border-indigo-500 hover:bg-indigo-700 transition-all flex items-center gap-2 active:scale-95"
                        >
                          {isGeneratingBanner ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wand2 className="w-3.5 h-3.5" />}
                          {bannerUrl ? 'Regenerate' : 'AI Banner Design'}
                        </button>
                      </div>
                   </div>
                   <div className="px-8 pb-8 pt-12 relative bg-white">
                      <div className="absolute -top-12 left-8 w-32 h-32 bg-gray-100 rounded-full border-4 border-white shadow-lg overflow-hidden flex items-center justify-center group-hover/header:-rotate-3 transition-transform duration-500">
                         <UserCircle className="w-24 h-24 text-gray-300" />
                      </div>
                      <div className="space-y-2 mt-4">
                        <div className="flex items-center justify-between">
                            <h4 className="text-2xl font-black text-gray-900">Professional Identity</h4>
                            <Linkedin className="w-6 h-6 text-[#0077b5]" />
                        </div>
                        <p className="text-sm font-bold text-gray-700 leading-tight pr-12 max-w-2xl">{optimizedProfile.headline}</p>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Location • Profile Indexing: High</p>
                        <div className="flex gap-2 pt-4">
                            <button className="bg-[#0077b5] text-white px-6 py-2 rounded-full text-[11px] font-black hover:bg-blue-700 transition-all shadow-md active:scale-95">Open to</button>
                            <button className="border-2 border-[#0077b5] text-[#0077b5] px-6 py-2 rounded-full text-[11px] font-black hover:bg-blue-50 transition-all active:scale-95">Add section</button>
                        </div>
                      </div>
                   </div>
                </div>

                {/* Headline Section */}
                <section className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] flex items-center gap-2">
                      <Type className="w-4 h-4" /> Professional Headline
                    </h4>
                    <button 
                      onClick={() => copyToClipboard(optimizedProfile.headline, 'headline')}
                      className="text-xs font-black text-[#0077b5] flex items-center gap-1 hover:underline active:scale-95 transition-all"
                    >
                      {copiedSection === 'headline' ? <Check className="w-4 h-4 text-emerald-500 animate-success-pop" /> : <Copy className="w-4 h-4" />}
                      {copiedSection === 'headline' ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <div className="p-8 bg-blue-50/20 rounded-[2.5rem] border border-blue-100 text-xl font-black text-gray-900 leading-snug hover:shadow-xl hover:shadow-blue-50/30 transition-all group">
                    {optimizedProfile.headline}
                  </div>
                </section>

                {/* About Section */}
                <section className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] flex items-center gap-2">
                      <Info className="w-4 h-4" /> Executive "About" Narrative
                    </h4>
                    <button 
                      onClick={() => copyToClipboard(optimizedProfile.about, 'about')}
                      className="text-xs font-black text-[#0077b5] flex items-center gap-1 hover:underline active:scale-95 transition-all"
                    >
                      {copiedSection === 'about' ? <Check className="w-4 h-4 text-emerald-500 animate-success-pop" /> : <Copy className="w-4 h-4" />}
                      Copy Story
                    </button>
                  </div>
                  <div className="p-8 bg-gray-50 rounded-[2.5rem] border border-gray-100 text-gray-700 leading-relaxed whitespace-pre-wrap text-sm font-medium hover:bg-white hover:shadow-xl transition-all">
                    {optimizedProfile.about}
                  </div>
                </section>

                {/* Experience Highlights Section */}
                <section className="space-y-4">
                    <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] flex items-center gap-2">
                      <Briefcase className="w-4 h-4" /> Targeted Experience Snapshots
                    </h4>
                    <div className="space-y-4">
                        {optimizedProfile.experienceHighlights.map((exp, idx) => (
                            <div key={idx} className="p-8 bg-white border border-gray-100 rounded-[2rem] hover:border-blue-200 transition-all group hover:shadow-lg hover:shadow-blue-50/50 hover:-translate-y-1">
                                <h5 className="text-xs font-black text-[#0077b5] mb-4 uppercase tracking-wider flex items-center gap-2">
                                  <div className="w-2 h-2 bg-[#0077b5] rounded-full group-hover:scale-150 transition-transform" />
                                  {exp.company}
                                </h5>
                                <ul className="space-y-3">
                                    {exp.highlights.map((h, i) => (
                                        <li key={i} className="flex gap-4 text-sm text-gray-600 font-medium leading-relaxed group-hover:text-gray-900 transition-colors">
                                            <div className="w-1 h-1 bg-gray-200 rounded-full mt-2.5 flex-shrink-0 group-hover:bg-blue-400 transition-colors" />
                                            {h}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>
                </section>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Banner & Keywords */}
                  <div className="space-y-8">
                    <section className="space-y-4">
                      <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] flex items-center gap-2">
                        <ImageIcon className="w-4 h-4" /> Visual Identity Concept
                      </h4>
                      <div className="p-6 bg-emerald-50 rounded-[2rem] border border-emerald-100 hover:bg-emerald-100/30 transition-colors">
                        <p className="text-xs text-emerald-900 italic font-bold leading-relaxed">
                          "{optimizedProfile.bannerConcept}"
                        </p>
                      </div>
                    </section>

                    <section className="space-y-4">
                      <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] flex items-center gap-2">
                        <Hash className="w-4 h-4" /> SEO Meta Keywords
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {optimizedProfile.seoKeywords.map((kw, i) => (
                          <span key={i} className="bg-white text-gray-600 px-4 py-2 rounded-xl text-[10px] font-black border border-gray-100 shadow-sm uppercase hover:border-blue-200 transition-colors cursor-default">
                            {kw}
                          </span>
                        ))}
                      </div>
                    </section>
                  </div>

                  {/* Post Ideas */}
                  <section className="space-y-4">
                    <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] flex items-center gap-2">
                      <MessageSquare className="w-4 h-4" /> Content Strategy & Post Ideas
                    </h4>
                    <div className="space-y-4">
                      {optimizedProfile.postIdeas.map((post, i) => (
                        <div key={i} className="bg-white border border-gray-100 rounded-[2rem] p-6 space-y-4 hover:shadow-xl hover:shadow-blue-50/50 transition-all border border-transparent hover:border-blue-100 hover:-translate-y-1">
                          <div>
                            <p className="text-[9px] font-black text-[#0077b5] uppercase mb-1 flex items-center gap-1.5">
                              <Lightbulb className="w-3 h-3" /> Idea {i + 1}
                            </p>
                            <h5 className="text-sm font-black text-gray-900 leading-tight">{post.title}</h5>
                          </div>
                          
                          <div className="space-y-3">
                            <div>
                              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest flex items-center gap-1.5 mb-2">
                                <Sparkles className="w-3 h-3 text-amber-400" /> The Hook
                              </p>
                              <div className="p-3 bg-gray-50 rounded-xl text-xs text-gray-700 italic border border-gray-100">
                                "{post.hook}"
                              </div>
                            </div>
                            
                            <div>
                              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest flex items-center gap-1.5 mb-2">
                                <FileText className="w-3 h-3 text-indigo-400" /> Outline
                              </p>
                              <p className="text-[11px] text-gray-600 leading-relaxed font-medium">
                                {post.outline}
                              </p>
                            </div>
                          </div>

                          <button 
                            onClick={() => copyToClipboard(`${post.title}\n\nHook: ${post.hook}\n\nOutline: ${post.outline}`, `post-${i}`)}
                            className="w-full py-2 bg-gray-50 hover:bg-blue-50 text-[10px] font-black text-gray-500 hover:text-[#0077b5] rounded-xl transition-all border border-gray-100 flex items-center justify-center gap-2 active:scale-95"
                          >
                            {copiedSection === `post-${i}` ? <Check className="w-3 h-3 text-emerald-500 animate-success-pop" /> : <Copy className="w-3 h-3" />}
                            {copiedSection === `post-${i}` ? 'Copied Plan' : 'Copy Post Plan'}
                          </button>
                        </div>
                      ))}
                    </div>
                  </section>
                </div>

                {/* Skills Grid */}
                <section className="space-y-4 pt-12 border-t border-gray-50">
                   <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] flex items-center gap-2">
                    <PenTool className="w-4 h-4" /> Top Algorithmic Skills
                  </h4>
                  <p className="text-[10px] text-gray-400 font-medium mb-4">Click any skill to copy it for your profile.</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                    {optimizedProfile.skills.map((skill, i) => (
                      <button 
                        key={i} 
                        onClick={() => copyToClipboard(skill, `skill-${i}`)}
                        className={`p-4 rounded-xl flex items-center justify-between group/skill transition-all border active:scale-95 ${
                          copiedSection === `skill-${i}` 
                            ? 'bg-emerald-50 border-emerald-200 ring-2 ring-emerald-100' 
                            : 'bg-gray-50 border-transparent hover:bg-white hover:shadow-md hover:border-blue-100 hover:-translate-y-1'
                        }`}
                      >
                        <span className={`text-[10px] font-black transition-colors ${
                          copiedSection === `skill-${i}` ? 'text-emerald-700' : 'text-gray-700 group-hover/skill:text-[#0077b5]'
                        }`}>
                          {skill}
                        </span>
                        {copiedSection === `skill-${i}` ? (
                          <Check className="w-3 h-3 text-emerald-600 animate-success-pop" />
                        ) : (
                          <ChevronRight className="w-3 h-3 text-gray-300 group-hover/skill:text-blue-500 transition-colors" />
                        )}
                      </button>
                    ))}
                  </div>
                </section>

                <div className="pt-12 text-center pb-8">
                    <button 
                        onClick={() => window.open('https://www.linkedin.com/in/', '_blank')}
                        className="inline-flex items-center gap-3 bg-[#0077b5] text-white px-10 py-5 rounded-[2rem] font-black text-sm shadow-2xl shadow-blue-100 hover:bg-blue-700 transition-all hover:-translate-y-1 active:scale-95 group"
                    >
                        Launch LinkedIn Identity <ExternalLink className="w-4 h-4 group-hover:rotate-12 transition-transform" />
                    </button>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-4">Profile Architect Engine v2.5</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LinkedInOptimizer;
