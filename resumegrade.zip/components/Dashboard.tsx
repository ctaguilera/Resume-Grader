
import React, { useState } from 'react';
import { ResumeAnalysis, JobMatch, JobFilters } from '../types';
import GradeCard from './GradeCard';
import AnalysisPanel from './AnalysisPanel';
import RewriteTool from './RewriteTool';
import JobMatchList from './JobMatch';
import InterviewPrep from './InterviewPrep';
import LinkedInOptimizer from './LinkedInOptimizer';
import JobFitAnalyzer from './JobFitAnalyzer';
import ResumePaper from './ResumePaper';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { FileText, Download, CheckCircle, Sparkles, Loader2, Printer, Check } from 'lucide-react';

interface DashboardProps {
  analysis: ResumeAnalysis;
  jobs: JobMatch[];
  activeTab: 'score' | 'rewrite' | 'jobs' | 'interview' | 'linkedin' | 'jobfit' | 'final';
  onApplyFix?: () => void;
  onUpdateResume?: (text: string) => void;
  onRefreshJobs?: (filters: JobFilters) => void;
  isRefreshingJobs?: boolean;
  originalText: string;
  initialJD?: string;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  analysis, 
  jobs, 
  activeTab, 
  onApplyFix, 
  onUpdateResume,
  onRefreshJobs, 
  isRefreshingJobs,
  originalText,
  initialJD
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const [showExportSuccess, setShowExportSuccess] = useState(false);

  const chartData = [
    { name: 'Score', value: analysis.totalScore },
    { name: 'Remaining', value: 100 - analysis.totalScore }
  ];

  const COLORS = ['#4f46e5', '#f3f4f6'];

  const handleExportPDF = () => {
    setIsExporting(true);
    setShowExportSuccess(false);
    // Use a timeout to allow the browser to process any UI updates before opening print dialog
    setTimeout(() => {
      window.print();
      setIsExporting(false);
      setShowExportSuccess(true);
      // Hide success message after 3 seconds
      setTimeout(() => setShowExportSuccess(false), 3000);
    }, 800);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Global Export Success Toast */}
      {showExportSuccess && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] bg-emerald-600 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="bg-white/20 p-1 rounded-full">
            <Check className="w-4 h-4" />
          </div>
          <p className="font-black text-sm uppercase tracking-widest">Document Export Triggered</p>
        </div>
      )}

      {activeTab === 'score' && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1 bg-white p-8 rounded-3xl border border-gray-100 flex flex-col items-center justify-center relative overflow-hidden group hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
               <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <span className="text-8xl font-black text-indigo-600 leading-none group-hover:scale-110 group-hover:rotate-6 transition-transform block">
                  {analysis.grade}
                </span>
               </div>
               
               <div className="relative w-48 h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={chartData}
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={0}
                        dataKey="value"
                        startAngle={90}
                        endAngle={-270}
                      >
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-5xl font-black text-gray-900 leading-none group-hover:scale-110 transition-transform">{analysis.grade}</span>
                    <span className="text-xs font-bold text-gray-500 mt-2 uppercase tracking-widest">Grade</span>
                  </div>
               </div>
               <div className="mt-4 text-center">
                  <p className="text-2xl font-bold text-gray-900">{analysis.totalScore}%</p>
                  <p className="text-sm text-gray-500">Overall Compatibility</p>
               </div>
            </div>

            <div className="md:col-span-2 bg-white p-8 rounded-3xl border border-gray-100 space-y-6 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group">
              <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                Score Breakdown
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-6">
                {[
                  { label: 'Grammar & Clarity', val: analysis.breakdown.grammar, weight: '25%' },
                  { label: 'ATS Compliance', val: analysis.breakdown.ats, weight: '30%' },
                  { label: 'Skimmability', val: analysis.breakdown.readability, weight: '20%' },
                  { label: 'Content Impact', val: analysis.breakdown.content, weight: '25%' }
                ].map((item, i) => (
                  <div key={i} className="group/item">
                    <div className="flex justify-between items-end mb-2">
                      <span className="text-sm font-semibold text-gray-700 group-hover/item:text-indigo-600 transition-colors">{item.label}</span>
                      <span className="text-xs text-gray-400 font-medium">Weight: {item.weight}</span>
                    </div>
                    <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-indigo-600 rounded-full transition-all duration-1000 ease-out group-hover:bg-indigo-500"
                        style={{ width: `${item.val}%` }}
                      ></div>
                    </div>
                    <p className="text-right text-xs font-bold mt-1 text-indigo-600">{item.val}/100</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <AnalysisPanel 
            suggestions={analysis.suggestions} 
            summary={analysis.summary} 
            onApplyFix={onApplyFix}
            originalText={originalText}
            onExportPDF={handleExportPDF}
          />
        </>
      )}

      {activeTab === 'rewrite' && (
        <RewriteTool analysis={analysis} onUpdateResume={onUpdateResume} />
      )}

      {activeTab === 'linkedin' && (
        <LinkedInOptimizer initialResumeText={originalText} />
      )}

      {activeTab === 'jobfit' && (
        <JobFitAnalyzer resumeText={originalText} onUpdateResume={onUpdateResume} initialJobDescription={initialJD} />
      )}

      {activeTab === 'jobs' && (
        <JobMatchList 
          jobs={jobs} 
          onRefreshJobs={onRefreshJobs || (() => {})} 
          isLoading={isRefreshingJobs} 
        />
      )}

      {activeTab === 'interview' && (
        <InterviewPrep initialResumeText={originalText} />
      )}

      {activeTab === 'final' && (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-700 max-w-5xl mx-auto pb-20">
          <div className="mb-12 flex flex-col md:flex-row items-center justify-between gap-6 bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
            <div className="flex items-center gap-5">
              <div className="bg-emerald-100 p-4 rounded-2xl">
                <CheckCircle className="w-8 h-8 text-emerald-600" />
              </div>
              <div>
                <h3 className="text-2xl font-black text-gray-900 tracking-tight">Final Optimized Resume</h3>
                <p className="text-gray-500 text-sm font-medium">Fully parsed Markdown layout ensuring ATS compatibility and visual excellence.</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button 
                onClick={handleExportPDF}
                disabled={isExporting}
                className={`px-8 py-4 rounded-2xl font-black shadow-xl transition-all flex items-center gap-3 active:scale-95 group disabled:opacity-50 min-w-[240px] justify-center ${
                  showExportSuccess ? 'bg-emerald-600 text-white' : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                {isExporting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Generating...
                  </>
                ) : showExportSuccess ? (
                  <>
                    <Check className="w-5 h-5 animate-success-pop" />
                    Export Started
                  </>
                ) : (
                  <>
                    <Printer className="w-5 h-5 group-hover:translate-y-0.5 transition-transform" /> 
                    Export Professional PDF
                  </>
                )}
              </button>
            </div>
          </div>
          
          <div className="relative group/resume">
            <div className="absolute -inset-4 bg-gradient-to-br from-indigo-500/10 to-violet-500/10 rounded-[3rem] blur-2xl opacity-0 group-hover/resume:opacity-100 transition-opacity duration-1000"></div>
            <div className="relative">
              <ResumePaper text={originalText} />
            </div>
            
            <div className="mt-8 text-center">
              <p className="text-gray-400 text-xs font-bold uppercase tracking-[0.2em] flex items-center justify-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400" /> Master Layout Engine v3.0
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
