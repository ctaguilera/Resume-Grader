
import React from 'react';
import { Grade } from '../types';

interface GradeCardProps {
  grade: Grade;
  score: number;
}

const GradeCard: React.FC<GradeCardProps> = ({ grade, score }) => {
  const getColor = (g: Grade) => {
    switch (g) {
      case 'A': return 'text-emerald-600';
      case 'B': return 'text-blue-600';
      case 'C': return 'text-amber-600';
      default: return 'text-red-600';
    }
  };

  return (
    <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between">
      <div>
        <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-1">Current Grade</h4>
        <p className={`text-6xl font-black ${getColor(grade)}`}>{grade}</p>
      </div>
      <div className="text-right">
        <p className="text-sm font-medium text-gray-500 mb-1">Compatibility Score</p>
        <div className="flex items-baseline justify-end gap-1">
          <span className="text-4xl font-bold text-gray-900">{score}</span>
          <span className="text-gray-400 font-bold">/100</span>
        </div>
      </div>
    </div>
  );
};

export default GradeCard;
