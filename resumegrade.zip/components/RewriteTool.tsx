
import React, { useState } from 'react';
import { ResumeAnalysis } from '../types';
import { gemini } from '../geminiService';
import { Sparkles, Loader2, Copy, Check, Wand2, Download, Zap, ListChecks, Target, ShieldCheck, TrendingUp, FileText, ArrowUpCircle } from 'lucide-react';

interface RewriteToolProps {
  analysis: ResumeAnalysis;
  onUpdateResume?: (text: string) => void;
}

const RewriteTool: React.FC<RewriteToolProps> = ({ analysis, onUpdateResume }) => {
  const [selectedSection, setSelectedSection] = useState<string>(analysis.sections.summary);
  const [targetRole, setTargetRole] = useState('');
  const [tone, setTone] = useState('Professional');
  const [rewrittenText, setRewrittenText] = useState('');
  const [isRewriting, setIsRewriting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [synced, setSynced] = useState(false);

  const handleRewrite = async (mode?: 'standard' | 'verbs' | 'readability' | 'quantify' | 'ats' | 'progression') => {
    setIsRewriting(true);
    setSynced(false);
    try {
      let result = '';
      if (mode === 'verbs') {
        result = await gemini.refineExperience(selectedSection);
      } else if (mode === 'readability') {
        result = await gemini.applyFullOptimization(selectedSection);
      } else if (mode === 'quantify') {
        result = await gemini.quantifyImpact(selectedSection);
      } else if (mode === 'ats') {
        result = await gemini.optimizeATS(selectedSection);
      } else if (mode === 'progression') {
        result = await gemini.optimizeProgression(selectedSection);
      } else {
        result = await gemini.rewriteContent(selectedSection, tone, targetRole);
      }
      setRewrittenText(result);
    } catch (err) {
      console.error(err);
    } finally {
      setIsRewriting(false);
    }
  };

  const handleSyncToMain = () => {
    if (!onUpdateResume || !rewrittenText) return;
    // Simple heuristic: if summary selected, replace summary; otherwise it's hard to know which exact bullet to replace
    // so we just update the text we have. Better would be a full document update.
    onUpdateResume(rewrittenText);
    setSynced(true);
    setTimeout(() => setSynced(false), 3000);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(rewrittenText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-3xl border border-gray-100 overflow-hidden">
      <div className="p-8 border-b border-gray-100 bg-gradient-to-br from-indigo-50 to-white">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-indigo-600 rounded-lg">
            <Wand2 className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900">AI Resume Reimagined</h3>
        </div>
        <p className="text-gray-500">Inject measurable results, leadership ownership, and high-impact language.</p>
      </div>

      <div className="p-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-700">Select Section</label>
            <select 
              className="w-full bg-gray-50 border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 transition-all text-sm"
              onChange={(e) => setSelectedSection(e.target.value)}
            >
              <option value={analysis.sections.summary}>Professional Summary</option>
              {analysis.sections.experience.map((exp, i) => (
                <option key={i} value={exp}>Experience: {exp.substring(0, 30)}...</option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-700">Target Role</label>
            <input 
              type="text" 
              placeholder="e.g. Senior Project Manager" 
              className="w-full bg-gray-50 border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 transition-all text-sm"
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-700">Tone</label>
            <div className="flex gap-2">
              {['Professional', 'Confident', 'Direct'].map((t) => (
                <button
                  key={t}
                  onClick={() => setTone(t)}
                  className={`flex-1 py-3 rounded-xl text-xs font-bold transition-all ${
                    tone === t ? 'bg-gray-900 text-white shadow-lg' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap justify-center gap-3">
          <button
            onClick={() => handleRewrite('readability')}
            disabled={isRewriting}
            className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-3 rounded-xl font-bold shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all disabled:opacity-50 text-xs"
          >
            {isRewriting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            Quick Rewrite
          </button>
          <button
            onClick={() => handleRewrite('ats')}
            disabled={isRewriting}
            className="flex items-center gap-2 bg-orange-600 text-white px-5 py-3 rounded-xl font-bold shadow-xl shadow-orange-100 hover:bg-orange-700 transition-all disabled:opacity-50 text-xs"
          >
            {isRewriting ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
            ATS Format
          </button>
          <button
            onClick={() => handleRewrite('quantify')}
            disabled={isRewriting}
            className="flex items-center gap-2 bg-violet-600 text-white px-5 py-3 rounded-xl font-bold shadow-xl shadow-violet-100 hover:bg-violet-700 transition-all disabled:opacity-50 text-xs"
          >
            {isRewriting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Target className="w-4 h-4" />}
            Quantify Results
          </button>
          <button
            onClick={() => handleRewrite('progression')}
            disabled={isRewriting}
            className="flex items-center gap-2 bg-blue-600 text-white px-5 py-3 rounded-xl font-bold shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all disabled:opacity-50 text-xs"
          >
            {isRewriting ? <Loader2 className="w-4 h-4 animate-spin" /> : <TrendingUp className="w-4 h-4" />}
            Show Progression
          </button>
          <button
            onClick={() => handleRewrite('verbs')}
            disabled={isRewriting}
            className="flex items-center gap-2 bg-cyan-600 text-white px-5 py-3 rounded-xl font-bold shadow-xl shadow-cyan-100 hover:bg-cyan-700 transition-all disabled:opacity-50 text-xs"
          >
            {isRewriting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
            Impact Verbs
          </button>
          <button
            onClick={() => handleRewrite('readability')}
            disabled={isRewriting}
            className="flex items-center gap-2 bg-emerald-600 text-white px-5 py-3 rounded-xl font-bold shadow-xl shadow-emerald-100 hover:bg-emerald-700 transition-all disabled:opacity-50 text-xs"
          >
            {isRewriting ? <Loader2 className="w-4 h-4 animate-spin" /> : <ListChecks className="w-4 h-4" />}
            Skimmability
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Original</h4>
            </div>
            <div className="bg-gray-50 p-6 rounded-2xl border border-gray-200 text-gray-600 leading-relaxed min-h-[300px] whitespace-pre-wrap text-sm">
              {selectedSection}
            </div>
          </div>

          <div className="space-y-4 relative">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-widest flex items-center gap-2">
                <Sparkles className="w-4 h-4" /> AI Optimized Output
              </h4>
            </div>
            
            <div className={`bg-indigo-50/30 p-6 rounded-2xl border-2 border-indigo-100 text-gray-900 leading-relaxed min-h-[300px] flex flex-col items-center justify-center transition-all ${isRewriting ? 'opacity-50' : ''}`}>
              {isRewriting ? (
                <div className="flex flex-col items-center gap-4">
                  <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
                  <p className="font-bold text-indigo-900">Analyzing Content Strength...</p>
                </div>
              ) : rewrittenText ? (
                <div className="w-full h-full whitespace-pre-wrap text-sm">
                  {rewrittenText}
                </div>
              ) : (
                <div className="text-center space-y-4">
                  <div className="p-4 bg-white rounded-full inline-block shadow-sm">
                    <TrendingUp className="w-8 h-8 text-indigo-600" />
                  </div>
                  <p className="text-gray-400 max-w-[250px] text-sm text-center font-medium">Use the tools above to transform your resume content into high-impact narratives.</p>
                </div>
              )}
            </div>
            
            {rewrittenText && !isRewriting && (
              <div className="flex flex-wrap gap-2 pt-2">
                 <button 
                  onClick={copyToClipboard}
                  className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-indigo-700 transition-all shadow-md active:scale-95 border border-indigo-500"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400 animate-success-pop" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied' : 'Copy to Clipboard'}
                </button>
                <button 
                  onClick={handleSyncToMain}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md active:scale-95 border ${
                    synced ? 'bg-emerald-600 text-white border-emerald-500' : 'bg-gray-900 text-white border-gray-800'
                  }`}
                >
                  {synced ? <Check className="w-4 h-4" /> : <ArrowUpCircle className="w-4 h-4" />}
                  {synced ? 'Applied to Final' : 'Sync to Final Resume'}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RewriteTool;
