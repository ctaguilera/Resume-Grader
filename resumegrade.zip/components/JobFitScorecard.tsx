
import React from 'react';
import { JobFitAnalysis } from '../types';
import { Check, X, Award, Target, Zap, AlertCircle } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

interface JobFitScorecardProps {
  analysis: JobFitAnalysis;
}

const JobFitScorecard: React.FC<JobFitScorecardProps> = ({ analysis }) => {
  const chartData = [
    { name: 'Match', value: analysis.matchScore },
    { name: 'Gap', value: 100 - analysis.matchScore }
  ];

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A': return 'bg-emerald-500 text-white';
      case 'B': return 'bg-blue-500 text-white';
      case 'C': return 'bg-amber-500 text-white';
      case 'D': return 'bg-orange-500 text-white';
      default: return 'bg-red-500 text-white';
    }
  };

  const getScoreColor = () => {
    if (analysis.matchScore >= 85) return '#10b981'; // emerald-500
    if (analysis.matchScore >= 70) return '#3b82f6'; // blue-500
    if (analysis.matchScore >= 50) return '#f59e0b'; // amber-500
    return '#ef4444'; // red-500
  };

  return (
    <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Top Header Badge */}
      <div className="bg-gray-900 px-8 py-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Target className="w-6 h-6 text-indigo-400" />
          <h3 className="text-xl font-black text-white">Job Fit Scorecard</h3>
        </div>
        <div className={`flex items-center gap-2 px-4 py-1.5 rounded-full font-black text-sm uppercase tracking-widest shadow-lg ${getGradeColor(analysis.matchLetterGrade)}`}>
          <Award className="w-4 h-4" />
          {analysis.matchGrade} ({analysis.matchLetterGrade})
        </div>
      </div>

      <div className="p-8 grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Score Visualizer */}
        <div className="lg:col-span-4 flex flex-col items-center justify-center space-y-6">
          <div className="relative w-56 h-56">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  innerRadius={75}
                  outerRadius={100}
                  paddingAngle={0}
                  dataKey="value"
                  startAngle={90}
                  endAngle={-270}
                  stroke="none"
                >
                  <Cell fill={getScoreColor()} />
                  <Cell fill="#f3f4f6" />
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl font-black text-gray-900">{analysis.matchScore}%</span>
              <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">Match Score</span>
            </div>
          </div>
          <div className="text-center px-4">
            <p className="text-sm font-bold text-gray-700 mb-1">Hiring Likelihood</p>
            <div className="h-2 w-48 bg-gray-100 rounded-full mx-auto overflow-hidden">
              <div 
                className="h-full bg-indigo-600 rounded-full transition-all duration-1000"
                style={{ width: `${analysis.hiringLikelihood}%` }}
              />
            </div>
            <p className="text-xs font-black text-indigo-600 mt-2">{analysis.hiringLikelihood}% Interview Probability</p>
          </div>
        </div>

        {/* Keyword Comparison Columns */}
        <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* What you have */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
              <div className="bg-emerald-100 p-1.5 rounded-lg">
                <Check className="w-4 h-4 text-emerald-600" />
              </div>
              <h4 className="font-black text-gray-900 uppercase tracking-tight text-sm">Matching Strengths</h4>
            </div>
            <div className="flex flex-wrap gap-2">
              {analysis.matchingSkills.length > 0 ? analysis.matchingSkills.map((skill, idx) => (
                <span 
                  key={idx} 
                  className="bg-emerald-50 text-emerald-700 px-3 py-1.5 rounded-xl text-[11px] font-bold border border-emerald-100 flex items-center gap-1.5"
                >
                  <Zap className="w-3 h-3" />
                  {skill}
                </span>
              )) : (
                <p className="text-xs text-gray-400 font-medium italic">No direct skill matches identified.</p>
              )}
            </div>
          </div>

          {/* What's missing */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
              <div className="bg-red-100 p-1.5 rounded-lg">
                <X className="w-4 h-4 text-red-600" />
              </div>
              <h4 className="font-black text-gray-900 uppercase tracking-tight text-sm">Identified Gaps</h4>
            </div>
            <div className="flex flex-wrap gap-2">
              {analysis.missingSkills.length > 0 ? analysis.missingSkills.map((skill, idx) => (
                <span 
                  key={idx} 
                  className="bg-red-50 text-red-700 px-3 py-1.5 rounded-xl text-[11px] font-bold border border-red-100 flex items-center gap-1.5"
                >
                  <AlertCircle className="w-3 h-3" />
                  {skill}
                </span>
              )) : (
                <p className="text-xs text-gray-400 font-medium italic">No critical missing keywords detected.</p>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Gap Analysis Summary */}
      <div className="bg-indigo-50/50 p-8 border-t border-gray-100">
        <h4 className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] mb-3">Strategic Gap Analysis</h4>
        <p className="text-sm text-gray-700 leading-relaxed font-medium">
          {analysis.gapAnalysis}
        </p>
      </div>
    </div>
  );
};

export default JobFitScorecard;
