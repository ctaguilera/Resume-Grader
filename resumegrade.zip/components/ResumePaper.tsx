
import React from 'react';
import ReactMarkdown from 'react-markdown';

interface ResumePaperProps {
  text: string;
  isPrintVersion?: boolean;
}

const ResumePaper: React.FC<ResumePaperProps> = ({ text, isPrintVersion = false }) => {
  return (
    <div 
      className={`bg-white mx-auto transition-all duration-500 relative overflow-hidden ${
        isPrintVersion 
          ? 'w-full p-[0.75in]' 
          : 'max-w-[850px] min-h-[1100px] p-20 rounded-lg border border-gray-100 shadow-2xl hover:shadow-indigo-100/50'
      }`}
      style={{ 
        fontFamily: "'Inter', 'system-ui', '-apple-system', sans-serif",
        color: '#1a1a1a',
        letterSpacing: '-0.01em'
      }}
    >
      {/* Executive Branding Line - Thin Purple Line at Top */}
      <div 
        className="absolute top-0 left-0 right-0 h-1 bg-indigo-600"
        style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact' }}
      ></div>

      <div className="resume-markdown">
        <ReactMarkdown>{text}</ReactMarkdown>
      </div>
      
      {/* Subtle Footer for Print - Optional but looks high-end */}
      {isPrintVersion && (
        <div className="mt-12 pt-8 border-t border-gray-50 text-center">
          <p className="text-[8pt] text-gray-300 font-medium uppercase tracking-[0.3em]">
            Generated via ResumeGrade Executive Engine
          </p>
        </div>
      )}
    </div>
  );
};

export default ResumePaper;
