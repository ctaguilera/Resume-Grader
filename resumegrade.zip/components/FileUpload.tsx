
import React, { useState } from 'react';
import { Upload, FileText, Loader2, AlertCircle, Target, Sparkles } from 'lucide-react';
import * as mammoth from 'mammoth';
import * as pdfjs from 'pdfjs-dist';

// Initialize PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = `https://esm.sh/pdfjs-dist@${pdfjs.version}/build/pdf.worker.mjs`;

interface FileUploadProps {
  onUpload: (text: string, jd?: string) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onUpload }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resumeText, setResumeText] = useState('');
  const [jdText, setJdText] = useState('');

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const extractPdfText = async (arrayBuffer: ArrayBuffer): Promise<string> => {
    const loadingTask = pdfjs.getDocument({ data: arrayBuffer });
    const pdf = await loadingTask.promise;
    let fullText = '';
    
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items
        .map((item: any) => item.str)
        .join(' ');
      fullText += pageText + '\n';
    }
    return fullText;
  };

  const extractDocxText = async (arrayBuffer: ArrayBuffer): Promise<string> => {
    const result = await mammoth.extractRawText({ arrayBuffer });
    return result.value;
  };

  const processFile = async (file: File) => {
    setIsParsing(true);
    setError(null);
    try {
      let extracted = '';
      if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
        const arrayBuffer = await file.arrayBuffer();
        extracted = await extractPdfText(arrayBuffer);
        if (!extracted.trim()) throw new Error("Could not extract text from PDF. It might be an image-only scan.");
      } else if (
        file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || 
        file.name.endsWith('.docx')
      ) {
        const arrayBuffer = await file.arrayBuffer();
        extracted = await extractDocxText(arrayBuffer);
      } else if (file.type === 'text/plain' || file.name.endsWith('.txt')) {
        extracted = await file.text();
      } else {
        throw new Error("Unsupported file format. Please upload PDF, DOCX, or TXT.");
      }
      setResumeText(extracted);
      // Auto-trigger analysis if no JD is present, otherwise wait for user to click "Analyze Match"
      if (!jdText.trim()) {
        onUpload(extracted);
      }
    } catch (err: any) {
      console.error("File processing error:", err);
      setError(err.message || "Failed to read file.");
    } finally {
      setIsParsing(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const canAnalyzeMatch = resumeText.trim() && jdText.trim();

  return (
    <div className="space-y-8">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-3xl p-12 transition-all duration-300 text-center ${
          isDragging 
            ? 'border-indigo-500 bg-indigo-50' 
            : 'border-gray-200 bg-white hover:border-indigo-300'
        } ${isParsing ? 'opacity-50 pointer-events-none' : ''}`}
      >
        <input
          type="file"
          id="resume-upload"
          className="hidden"
          accept=".pdf,.docx,.txt"
          onChange={handleFileChange}
        />
        <label htmlFor="resume-upload" className="cursor-pointer group">
          <div className="bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
            {isParsing ? (
              <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
            ) : (
              <Upload className="w-8 h-8 text-indigo-600" />
            )}
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">
            {isParsing ? 'Extracting text...' : 'Drop your resume here'}
          </h3>
          <p className="text-gray-500 mb-4">Supports PDF, DOCX, and TXT formats</p>
          <div className="inline-block bg-indigo-600 text-white px-6 py-2 rounded-xl font-semibold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-colors">
            {isParsing ? 'Processing...' : 'Select File'}
          </div>
        </label>
      </div>

      {error && (
        <div className="p-4 bg-red-50 rounded-xl border border-red-100 flex items-center gap-3 text-red-700 animate-in fade-in zoom-in duration-300">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm font-medium">{error}</p>
        </div>
      )}

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-gray-200"></div>
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-4 bg-gray-50 text-gray-500 font-bold uppercase tracking-widest">Manual Input</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Resume Text Area */}
        <div className="bg-white rounded-[2rem] p-6 border border-gray-200 shadow-sm flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <FileText className="w-5 h-5 text-indigo-600" />
            <h4 className="font-bold text-gray-900 text-sm">Paste Resume Text</h4>
          </div>
          <textarea
            rows={8}
            placeholder="Paste your resume content here..."
            className="w-full border-0 focus:ring-0 text-gray-600 placeholder:text-gray-400 resize-none outline-none font-medium text-sm flex-grow"
            value={resumeText}
            onChange={(e) => setResumeText(e.target.value)}
          />
        </div>

        {/* Job Description Text Area */}
        <div className="bg-white rounded-[2rem] p-6 border border-gray-200 shadow-sm flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <Target className="w-5 h-5 text-violet-600" />
            <h4 className="font-bold text-gray-900 text-sm">Target Job Description (Optional)</h4>
          </div>
          <textarea
            rows={8}
            placeholder="Paste the job you're applying for to check compatibility..."
            className="w-full border-0 focus:ring-0 text-gray-600 placeholder:text-gray-400 resize-none outline-none font-medium text-sm flex-grow"
            value={jdText}
            onChange={(e) => setJdText(e.target.value)}
          />
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
        {canAnalyzeMatch ? (
          <button
            onClick={() => onUpload(resumeText, jdText)}
            disabled={isParsing}
            className="w-full sm:w-auto flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 text-white px-10 py-4 rounded-2xl font-black shadow-xl shadow-indigo-100 hover:scale-105 active:scale-95 transition-all group"
          >
            Analyze Match Score <Sparkles className="w-5 h-5 group-hover:rotate-12 transition-transform" />
          </button>
        ) : (
          <button
            onClick={() => resumeText.trim() && onUpload(resumeText)}
            disabled={!resumeText.trim() || isParsing}
            className="w-full sm:w-auto flex items-center justify-center gap-2 bg-gray-900 text-white px-10 py-4 rounded-2xl font-black shadow-xl hover:bg-black disabled:opacity-50 active:scale-95 transition-all"
          >
            Analyze Resume <FileText className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};

export default FileUpload;
