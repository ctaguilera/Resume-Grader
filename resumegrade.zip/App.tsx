
import React, { useState, useEffect } from 'react';
import { ResumeAnalysis, JobMatch, UserLocation, JobFilters } from './types';
import { gemini } from './geminiService';
import FileUpload from './components/FileUpload';
import Dashboard from './components/Dashboard';
import ResumePaper from './components/ResumePaper';
import { Layout, FileText, BarChart3, Briefcase, Zap, Loader2, Sparkles, AlertCircle, RefreshCcw, BrainCircuit, Linkedin, Target, CheckCircle } from 'lucide-react';

const App: React.FC = () => {
  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);
  const [originalText, setOriginalText] = useState<string>('');
  const [initialJD, setInitialJD] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshingJobs, setIsRefreshingJobs] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [jobs, setJobs] = useState<JobMatch[]>([]);
  const [activeTab, setActiveTab] = useState<'score' | 'rewrite' | 'jobs' | 'interview' | 'linkedin' | 'jobfit' | 'final'>('score');
  const [location, setLocation] = useState<UserLocation | null>(null);

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLocation({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude
          });
        },
        (err) => console.warn("Location permission denied or unavailable.")
      );
    }
  }, []);

  const handleFileUpload = async (text: string, jd?: string) => {
    setIsLoading(true);
    setError(null);
    setOriginalText(text);
    if (jd) setInitialJD(jd);
    
    try {
      const result = await gemini.analyzeResume(text);
      setAnalysis(result);
      
      if (jd) {
        setActiveTab('jobfit');
      }

      if (result.jobKeywords && result.jobKeywords.length > 0) {
        const jobResults = await gemini.findMatchingJobs(result.jobKeywords, location);
        setJobs(jobResults);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to analyze resume. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateResume = async (newText: string) => {
    setIsOptimizing(true);
    setOriginalText(newText);
    try {
      const result = await gemini.analyzeResume(newText);
      setAnalysis(result);
    } catch (err: any) {
      console.error("Analysis update failed", err);
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleRefreshJobs = async (filters: JobFilters) => {
    if (!analysis) return;
    setIsRefreshingJobs(true);
    try {
      const jobResults = await gemini.findMatchingJobs(analysis.jobKeywords, location, filters);
      setJobs(jobResults);
    } catch (err: any) {
      console.error("Job refresh failed", err);
    } finally {
      setIsRefreshingJobs(false);
    }
  };

  const handleAutoFix = async () => {
    if (!originalText) return;
    setIsOptimizing(true);
    setError(null);
    try {
      const fixedText = await gemini.applyFullOptimization(originalText);
      setOriginalText(fixedText);
      const result = await gemini.analyzeResume(fixedText);
      setAnalysis(result);
      setActiveTab('score');
    } catch (err: any) {
      setError('Failed to apply optimizations. Please try again.');
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleReset = () => {
    setAnalysis(null);
    setOriginalText('');
    setInitialJD('');
    setJobs([]);
    setActiveTab('score');
    setError(null);
  };

  return (
    <div className="min-h-screen animate-gradient pb-20">
      {/* Hidden container for PDF printing */}
      <div id="printable-resume-container" className="hidden">
        <ResumePaper text={originalText} isPrintVersion={true} />
      </div>

      <header className="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div 
            className="flex items-center gap-2 cursor-pointer group transition-transform active:scale-95" 
            onClick={handleReset}
          >
            <div className="bg-indigo-600 p-2 rounded-lg group-hover:rotate-12 transition-transform duration-300">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-600 group-hover:tracking-tight transition-all duration-300">
              ResumeGrade
            </h1>
          </div>
          <div className="flex items-center gap-4">
            {analysis && (
              <button
                disabled={isOptimizing}
                onClick={handleAutoFix}
                className="flex items-center gap-2 text-sm font-bold text-indigo-600 hover:bg-indigo-50 px-3 py-2 rounded-lg transition-all active:scale-95 disabled:opacity-50"
                title="Optimize readability, grammar, and action verbs"
              >
                {isOptimizing ? <RefreshCcw className="w-4 h-4 animate-spin" /> : <RefreshCcw className="w-4 h-4 group-hover:rotate-180 transition-transform duration-500" />}
                One-Click Optimize
              </button>
            )}
            {analysis && (
              <button
                onClick={handleReset}
                className="text-sm font-medium text-gray-500 hover:text-indigo-600 transition-all hover:translate-x-1 active:scale-90"
              >
                Upload New
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!analysis && !isLoading && (
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12 animate-in fade-in slide-in-from-top-4 duration-1000">
              <h2 className="text-4xl font-extrabold text-gray-900 sm:text-5xl mb-4 tracking-tight">
                Land your dream job with an <span className="text-indigo-600 underline decoration-indigo-200 underline-offset-8">A+ Resume</span>.
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Get instant grading, ATS compatibility checks, and AI-powered optimization tailored to your target roles.
              </p>
            </div>
            
            <div className="hover:scale-[1.01] transition-transform duration-500">
              <FileUpload onUpload={handleFileUpload} />
            </div>
            
            {error && (
              <div className="mt-6 p-4 bg-red-50 rounded-xl border border-red-100 flex items-center gap-3 text-red-700 animate-in zoom-in duration-300">
                <AlertCircle className="w-5 h-5" />
                <p className="text-sm font-medium">{error}</p>
              </div>
            )}

            <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { icon: Zap, title: "ATS Optimization", desc: "Scan for keywords and formatting that cause resumes to get ghosted." },
                { icon: BarChart3, title: "Detailed Grading", desc: "Deep-dive analysis using Thinking Mode for executive insights." },
                { icon: BrainCircuit, title: "Interview Prep", desc: "Tailored Q&A powered by Gemini 3 Pro thinking mode." }
              ].map((feature, i) => (
                <div 
                  key={i} 
                  className="bg-white/50 border border-gray-100 p-6 rounded-2xl hover:bg-white hover:shadow-xl hover:-translate-y-2 transition-all duration-500 group animate-in fade-in slide-in-from-bottom-8"
                  style={{ animationDelay: `${i * 150}ms` }}
                >
                  <feature.icon className="w-8 h-8 text-indigo-500 mb-4 group-hover:scale-110 group-hover:text-indigo-600 transition-all duration-300" />
                  <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                  <p className="text-gray-500 text-sm">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {(isLoading || isOptimizing) && (
          <div className="flex flex-col items-center justify-center min-h-[60vh]">
            <div className="relative hover:scale-110 transition-transform duration-700">
              <Loader2 className="w-16 h-16 text-indigo-600 animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                <FileText className="w-6 h-6 text-indigo-400" />
              </div>
            </div>
            <h2 className="mt-8 text-2xl font-bold text-gray-900">
              {isOptimizing ? 'Improving readability & impact...' : 'Analyzing with Thinking Mode...'}
            </h2>
            <p className="mt-2 text-gray-500 animate-pulse text-center max-w-sm">
              {isOptimizing ? 'Shortening long bullets and cleaning up formatting' : 'Simulating recruiter review and running ATS deep-scan (Thinking Mode enabled)'}
            </p>
          </div>
        )}

        {analysis && !isOptimizing && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <nav className="lg:col-span-3 space-y-2">
              {[
                { id: 'score', label: 'Score & Feedback', icon: BarChart3 },
                { id: 'jobfit', label: 'JD Match Score', icon: Target },
                { id: 'rewrite', label: 'AI Rewrite Tool', icon: Zap },
                { id: 'final', label: 'Final Resume', icon: CheckCircle },
                { id: 'linkedin', label: 'LinkedIn Optimizer', icon: Linkedin },
                { id: 'jobs', label: 'Job Matches', icon: Briefcase },
                { id: 'interview', label: 'Interview Prep', icon: BrainCircuit },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 font-medium active:scale-95 group relative overflow-hidden ${
                    activeTab === item.id 
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200 -translate-y-0.5' 
                      : 'bg-white hover:bg-gray-50 text-gray-600 hover:shadow-sm'
                  }`}
                >
                  <item.icon className={`w-5 h-5 transition-transform duration-300 ${activeTab === item.id ? 'scale-110' : 'group-hover:scale-110'}`} />
                  {item.label}
                  {activeTab === item.id && (
                    <span className="absolute right-3 w-1.5 h-1.5 bg-white rounded-full animate-ping"></span>
                  )}
                </button>
              ))}
              
              <div className="mt-8 p-6 bg-indigo-50 rounded-2xl border border-indigo-100 hover:bg-indigo-100/50 transition-colors duration-500 group">
                <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-wider mb-2 flex items-center gap-2">
                  <Sparkles className="w-3 h-3 group-hover:rotate-12 transition-transform" /> Pro Tip
                </h4>
                <p className="text-sm text-indigo-800 leading-relaxed">
                  Our analysis uses Gemini 3 Pro with Thinking Mode to simulate exactly how an executive recruiter would evaluate your background.
                </p>
              </div>
            </nav>

            <div className="lg:col-span-9">
              <Dashboard 
                analysis={analysis} 
                jobs={jobs} 
                activeTab={activeTab}
                onApplyFix={handleAutoFix}
                onUpdateResume={handleUpdateResume}
                onRefreshJobs={handleRefreshJobs}
                isRefreshingJobs={isRefreshingJobs}
                originalText={originalText}
                initialJD={initialJD}
              />
            </div>
          </div>
        )}
      </main>

      {analysis && (
        <div className="md:hidden fixed bottom-4 left-4 right-4 bg-indigo-600 p-4 rounded-2xl shadow-xl flex items-center justify-between text-white z-50 animate-in slide-in-from-bottom-10 duration-500 active:scale-95 transition-transform">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs opacity-80 uppercase font-black tracking-widest">Grade</p>
              <p className="font-bold text-xl leading-none">{analysis?.grade || '-'}</p>
            </div>
          </div>
          <button 
            onClick={handleReset}
            className="bg-white text-indigo-600 px-4 py-2 rounded-lg font-bold text-sm hover:bg-indigo-50 active:scale-90 transition-all shadow-sm"
          >
            New Analysis
          </button>
        </div>
      )}
    </div>
  );
};

export default App;
